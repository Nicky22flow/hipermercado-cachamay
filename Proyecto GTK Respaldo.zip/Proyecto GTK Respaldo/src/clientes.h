//clientes.h
#ifndef CLIENTES_H
#define CLIENTES_H

#include <gtk/gtk.h>

// Definición de la estructura de Cliente
typedef struct {
    char cedula[20];
    char nombre[50];
    char apellido[50];
    char direccion[100];
    char telefono[12];
} Cliente;

void mostrar_formulario_registro(GtkWidget *widget, gpointer data);
void mostrar_formulario_modificar_cliente(GtkWidget *widget, gpointer data);
void mostrar_formulario_eliminar_cliente(GtkWidget *widget, gpointer data);
void mostrar_clientes(GtkWidget *widget, gpointer data);
int registrar_cliente(const char *archivo, Cliente cliente);
void guardar_cliente_callback(GtkDialog *dialog, gint response_id, gpointer user_data);
int modificar_cliente(const char *archivo, const char *cedula, Cliente nuevo_cliente);
int cedula_duplicada_cliente(const char *archivo, const char *cedula);
int validar_campos_cliente(Cliente cliente);
int buscar_cliente(const char *archivo, const char *cedula, Cliente *resultado);
void buscar_cliente_callback(GtkWidget *widget, gpointer data);
void guardar_cliente_modificado(GtkWidget *widget, gpointer data);
int eliminar_cliente(const char *archivo, const char *cedula);
void eliminar_cliente_callback(GtkWidget *widget, gpointer data);
int leerClientesDesdeArchivo(const char *archivo, Cliente *clientes, int *num_clientes);
int buscar_cliente_por_cedula(const char *archivo, const char *cedula, Cliente *cliente);
Cliente obtener_cliente_seleccionado(GtkComboBoxText *combo_cliente, Cliente *clientes, int num_clientes);

// Nueva función para crear la ventana de clientes
void crear_ventana_clientes(GtkWidget *widget, gpointer data);

#endif // CLIENTES_H