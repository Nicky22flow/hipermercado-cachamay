//src/ventas.h
#ifndef VENTAS_H
#define VENTAS_H

#include <gtk/gtk.h>
#include "facturas.h"
#include "control_cajas.h"

// Funciones para gestionar ventas
void mostrar_ventana_opciones(GtkWidget *widget, gpointer data);
void mostrar_ventas(GtkWidget *widget, gpointer data);
void consultar_ventas_diarias_por_caja(GtkWidget *widget, gpointer data);
void consultar_ventas_mensuales_por_caja(GtkWidget *widget, gpointer data);
void consultar_total_ventas_diarias(GtkWidget *widget, gpointer data);
void consultar_total_ventas_mensuales(GtkWidget *widget, gpointer data);

#endif // VENTAS_H