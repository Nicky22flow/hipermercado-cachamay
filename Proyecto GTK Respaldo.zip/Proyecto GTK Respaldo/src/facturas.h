// src/facturas.h
#ifndef FACTURAS_H
#define FACTURAS_H

#include "clientes.h"
#include "productos.h"

#define MAX_ITEMS_VENTA 100

typedef struct {
    int numero_factura;
    int numero_caja; // Agregar el campo numero_caja
    char fecha[20];
    Cliente cliente;
    Producto productos[MAX_ITEMS_VENTA];
    int num_productos;
    float impuesto;
    float monto_total;
} Factura;

void mostrarVentanaFactura(GtkWidget *widget, gpointer data);
void guardarFacturaEnArchivo(Factura factura, const char *archivo);
void mostrarFormatoFactura(Factura factura);
void agregarProducto(Factura *factura, Producto producto);
void calcularTotales(Factura *factura, float tasa_cambio, float monto_base, float iva);
void modificar_factura(GtkWidget *widget, gpointer data);
void eliminar_factura(GtkWidget *widget, gpointer data);
void mostrar_facturas(GtkWidget *widget, gpointer data);
int leerFacturasDesdeArchivo(const char *archivo, Factura *facturas);
void guardarFacturasEnArchivo(const char *archivo, Factura *facturas, int num_facturas);

#endif // FACTURAS_H