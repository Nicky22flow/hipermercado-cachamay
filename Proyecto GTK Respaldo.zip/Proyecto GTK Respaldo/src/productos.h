// productos.h
#ifndef PRODUCTOS_H
#define PRODUCTOS_H

#include <gtk/gtk.h>

// Definición de la estructura de Producto
typedef struct
{
    char codigo[8];    // Código del producto
    char nombre[50];   // Nombre del producto
    float precio;      // Precio del producto
    int cantidad;      // Cantidad disponible
} Producto;

void crear_ventana_productos(GtkWidget *widget, gpointer data);
void mostrar_formulario_registro_productos(GtkWidget *widget, gpointer data);
void mostrar_formulario_modificar_producto(GtkWidget *widget, gpointer data);
void mostrar_formulario_eliminar_producto(GtkWidget *widget, gpointer data);
void mostrar_productos(GtkWidget *widget, gpointer data);
// Función para registrar un producto
int registrar_producto(const char *archivo, Producto producto);

// Callback para guardar un producto desde un diálogo GTK
void guardar_producto_callback(GtkDialog *dialog, gint response_id, gpointer user_data);

// Función para modificar un producto existente
int modificar_producto(const char *archivo, const char *codigo, Producto nuevo_producto);

// Función para verificar si un código ya está registrado
int codigo_duplicado_producto(const char *archivo, const char *codigo);

// Función para validar los campos de un producto
int validar_campos_producto(Producto producto);

// Función para buscar un producto por su código
int buscar_producto(const char *archivo, const char *codigo, Producto *resultado);

// Callback para buscar un producto desde un widget GTK
void buscar_producto_callback(GtkWidget *widget, gpointer data);

// Callback para guardar un producto modificado desde un widget GTK
void guardar_producto_modificado(GtkWidget *widget, gpointer data);

// Función para eliminar un producto por su código
int eliminar_producto(const char *archivo, const char *codigo);

// Callback para eliminar un producto desde un widget GTK
void eliminar_producto_callback(GtkWidget *widget, gpointer data);

#endif // PRODUCTOS_H
