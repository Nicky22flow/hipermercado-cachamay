#include "control_cajas.h"
#include "facturas.h"
#include "ventas.h"
#include <gtk/gtk.h>
#include <time.h>

// Declaraciones de funciones
void mostrar_ventas(GtkWidget *widget, gpointer data);
void consultar_ventas_diarias_por_caja(GtkWidget *widget, gpointer data);
void consultar_ventas_mensuales_por_caja(GtkWidget *widget, gpointer data);
void consultar_total_ventas_diarias(GtkWidget *widget, gpointer data);
void consultar_total_ventas_mensuales(GtkWidget *widget, gpointer data);

// Función para mostrar la ventana de opciones
void mostrar_ventana_opciones(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *vbox, *button_crear, *button_modificar, *button_eliminar, *button_mostrar;

    // Crear una nueva ventana
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Opciones de Ventas");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    // Crear un contenedor vertical
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    // Botón para crear venta
    button_crear = gtk_button_new_with_label("Crear Venta");
    g_signal_connect(button_crear, "clicked", G_CALLBACK(on_registrar_venta), window);
    gtk_box_pack_start(GTK_BOX(vbox), button_crear, TRUE, TRUE, 0);

    // Botón para modificar venta
    button_modificar = gtk_button_new_with_label("Modificar Venta");
    g_signal_connect(button_modificar, "clicked", G_CALLBACK(modificar_factura), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_modificar, TRUE, TRUE, 0);

    // Botón para eliminar venta
    button_eliminar = gtk_button_new_with_label("Eliminar Venta");
    g_signal_connect(button_eliminar, "clicked", G_CALLBACK(eliminar_factura), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_eliminar, TRUE, TRUE, 0);

    // Botón para mostrar ventas
    button_mostrar = gtk_button_new_with_label("Mostrar Ventas");
    g_signal_connect(button_mostrar, "clicked", G_CALLBACK(mostrar_ventas), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_mostrar, TRUE, TRUE, 0);

    gtk_widget_show_all(window);
}

// Función para mostrar las ventas
void mostrar_ventas(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *vbox, *hbox, *label, *combo_box, *button_diario, *button_mensual, *button_total_diario, *button_total_mensual;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Consultar Ventas");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    // Selección de caja
    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    label = gtk_label_new("Caja:");
    combo_box = gtk_combo_box_text_new();
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(hbox), combo_box, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

    // Cargar cajas desde el archivo
    Caja cajas[100];
    int num_cajas = cargar_cajas_desde_archivo(cajas);
    for (int i = 0; i < num_cajas; i++) {
        char caja_info[100];
        snprintf(caja_info, sizeof(caja_info), "Caja %d - %s", cajas[i].numero_caja, cajas[i].nombre_responsable);
        gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_box), caja_info);
    }

    // Botón para consultar ventas diarias por caja
    button_diario = gtk_button_new_with_label("Ventas Diarias por Caja");
    g_signal_connect(button_diario, "clicked", G_CALLBACK(consultar_ventas_diarias_por_caja), combo_box);
    gtk_box_pack_start(GTK_BOX(vbox), button_diario, TRUE, TRUE, 0);

    // Botón para consultar ventas mensuales por caja
    button_mensual = gtk_button_new_with_label("Ventas Mensuales por Caja");
    g_signal_connect(button_mensual, "clicked", G_CALLBACK(consultar_ventas_mensuales_por_caja), combo_box);
    gtk_box_pack_start(GTK_BOX(vbox), button_mensual, TRUE, TRUE, 0);

    // Botón para consultar total de ventas diarias
    button_total_diario = gtk_button_new_with_label("Total Ventas Diarias");
    g_signal_connect(button_total_diario, "clicked", G_CALLBACK(consultar_total_ventas_diarias), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_total_diario, TRUE, TRUE, 0);

    // Botón para consultar total de ventas mensuales
    button_total_mensual = gtk_button_new_with_label("Total Ventas Mensuales");
    g_signal_connect(button_total_mensual, "clicked", G_CALLBACK(consultar_total_ventas_mensuales), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_total_mensual, TRUE, TRUE, 0);

    gtk_widget_show_all(window);
}

// Función para consultar ventas diarias por caja
void consultar_ventas_diarias_por_caja(GtkWidget *widget, gpointer data) {
    GtkComboBoxText *combo_box = GTK_COMBO_BOX_TEXT(data);
    int caja_index = gtk_combo_box_get_active(GTK_COMBO_BOX(combo_box));
    if (caja_index < 0) {
        printf("Error: No se seleccionó una caja válida.\n");
        return;
    }

    Caja cajas[100];
    int num_cajas = cargar_cajas_desde_archivo(cajas);
    Caja caja_seleccionada = cajas[caja_index];

    // Obtener la fecha actual
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char fecha_actual[20];
    strftime(fecha_actual, sizeof(fecha_actual), "%d-%m-%Y", &tm);

    // Leer las facturas desde el archivo
    Factura facturas[100];
    int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

    float total_ventas = 0.0;
    for (int i = 0; i < num_facturas; i++) {
        if (facturas[i].numero_caja == caja_seleccionada.numero_caja && strcmp(facturas[i].fecha, fecha_actual) == 0) {
            total_ventas += facturas[i].monto_total;
        }
    }

    // Mostrar los resultados en una ventana
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Ventas diarias por caja %d: Bs %.2f", caja_seleccionada.numero_caja, total_ventas);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

// Función para consultar ventas mensuales por caja
void consultar_ventas_mensuales_por_caja(GtkWidget *widget, gpointer data) {
    GtkComboBoxText *combo_box = GTK_COMBO_BOX_TEXT(data);
    int caja_index = gtk_combo_box_get_active(GTK_COMBO_BOX(combo_box));
    if (caja_index < 0) {
        printf("Error: No se seleccionó una caja válida.\n");
        return;
    }

    Caja cajas[100];
    int num_cajas = cargar_cajas_desde_archivo(cajas);
    Caja caja_seleccionada = cajas[caja_index];

    // Obtener la fecha actual
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char mes_actual[20];
    strftime(mes_actual, sizeof(mes_actual), "%m-%Y", &tm);

    // Leer las facturas desde el archivo
    Factura facturas[100];
    int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

    float total_ventas = 0.0;
    for (int i = 0; i < num_facturas; i++) {
        char mes_factura[20];
        strncpy(mes_factura, facturas[i].fecha + 3, 7); // Extraer el mes y año de la fecha
        mes_factura[7] = '\0';
        if (facturas[i].numero_caja == caja_seleccionada.numero_caja && strcmp(mes_factura, mes_actual) == 0) {
            total_ventas += facturas[i].monto_total;
        }
    }

    // Mostrar los resultados en una ventana
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Ventas mensuales por caja %d: Bs %.2f", caja_seleccionada.numero_caja, total_ventas);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

// Función para consultar el total de ventas diarias
void consultar_total_ventas_diarias(GtkWidget *widget, gpointer data) {
    // Obtener la fecha actual
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char fecha_actual[20];
    strftime(fecha_actual, sizeof(fecha_actual), "%d-%m-%Y", &tm);

    // Leer las facturas desde el archivo
    Factura facturas[100];
    int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

    float total_ventas = 0.0;
    for (int i = 0; i < num_facturas; i++) {
        if (strcmp(facturas[i].fecha, fecha_actual) == 0) {
            total_ventas += facturas[i].monto_total;
        }
    }

    // Mostrar los resultados en una ventana
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Total de ventas diarias: Bs %.2f", total_ventas);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

// Función para consultar el total de ventas mensuales
void consultar_total_ventas_mensuales(GtkWidget *widget, gpointer data) {
    // Obtener la fecha actual
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char mes_actual[20];
    strftime(mes_actual, sizeof(mes_actual), "%m-%Y", &tm);

    // Leer las facturas desde el archivo
    Factura facturas[100];
    int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

    float total_ventas = 0.0;
    for (int i = 0; i < num_facturas; i++) {
        char mes_factura[20];
        strncpy(mes_factura, facturas[i].fecha + 3, 7); // Extraer el mes y año de la fecha
        mes_factura[7] = '\0';
        if (strcmp(mes_factura, mes_actual) == 0) {
            total_ventas += facturas[i].monto_total;
        }
    }

    // Mostrar los resultados en una ventana
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Total de ventas mensuales: Bs %.2f", total_ventas);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}