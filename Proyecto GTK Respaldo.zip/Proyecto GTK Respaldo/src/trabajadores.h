// trabajadores.h
#ifndef EMPLEADOS_H
#define EMPLEADOS_H

#include <gtk/gtk.h>

// Definición de la estructura Trabajador
typedef struct
{
    char cedula[20];           // Cédula del trabajador
    char nombre[50];           // Nombre del trabajador
    char apellido[50];         // Apellido del trabajador
    char telefono[12];         // Teléfono del trabajador
    char direccion[100];       // Dirección del trabajador
    char numero_trabajador;    // Número del trabajador
} Trabajador;

// Función para registrar un trabajador
int registrar_trabajador(const char *archivo, Trabajador trabajador);

// Callback para guardar un trabajador desde un diálogo GTK
void guardar_trabajador_callback(GtkDialog *dialog, gint response_id, gpointer user_data);

// Función para modificar un trabajador existente
int modificar_trabajador(const char *archivo, const char *cedula, Trabajador nuevo_trabajador);

// Función para verificar si una cédula ya está registrada
int cedula_duplicada_trabajador(const char *archivo, const char *cedula);

// Función para validar los campos de un trabajador
int validar_campos_trabajador(Trabajador trabajador);

// Función para buscar un trabajador por su cédula
int buscar_trabajador(const char *archivo, const char *cedula, Trabajador *resultado);

// Callback para buscar un trabajador desde un widget GTK
void buscar_trabajador_callback(GtkWidget *widget, gpointer data);

// Callback para guardar un trabajador modificado desde un widget GTK
void guardar_trabajador_modificado(GtkWidget *widget, gpointer data);

// Función para eliminar un trabajador por su cédula
int eliminar_trabajador(const char *archivo, const char *cedula);

// Callback para eliminar un trabajador desde un widget GTK
void eliminar_trabajador_callback(GtkWidget *widget, gpointer data);

// Función para crear la ventana de trabajadores
void crear_ventana_trabajadores(GtkWidget *widget, gpointer data);

// Función para mostrar el formulario de registro de trabajadores
void mostrar_formulario_registro_trabajador(GtkWidget *widget, gpointer data);

// Función para mostrar el formulario de modificación de trabajadores
void mostrar_formulario_modificar_trabajador(GtkWidget *widget, gpointer data);

// Función para mostrar el formulario de eliminación de trabajadores
void mostrar_formulario_eliminar_trabajador(GtkWidget *widget, gpointer data);

// Función para mostrar la lista de trabajadores
void mostrar_trabajadores(GtkWidget *widget, gpointer data);

#endif // EMPLEADOS_H