//gui_cajas.c
#include "control_cajas.h"
#include <gtk/gtk.h>

// Función para cerrar la ventana
static void cerrar_ventana(GtkWidget *widget, gpointer data)
{
    gtk_widget_destroy(GTK_WIDGET(data));
}

// Función para mostrar la ventana de control de cajas
void mostrar_ventana_control_cajas()
{
    gint argc = 0;
    gchar **argv = NULL;
    gtk_init(&argc, &argv);

    // Crear ventana principal
    GtkWidget *ventana = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(ventana), "Control de Cajas");
    gtk_window_set_default_size(GTK_WINDOW(ventana), 600, 400);
    g_signal_connect(ventana, "destroy", G_CALLBACK(gtk_main_quit), NULL);

        // Establecer el color de fondo de la ventana
        GdkRGBA color; // Declarar una estructura de color
        gdk_rgba_parse(&color, "#387647"); // Parsear el color desde una cadena
        G_GNUC_BEGIN_IGNORE_DEPRECATIONS // Ignorar las advertencias de deprecación
        gtk_widget_override_background_color(GTK_WIDGET(ventana), GTK_STATE_FLAG_NORMAL, &color); // Establecer el color de fondo
        G_GNUC_BEGIN_IGNORE_DEPRECATIONS

    // Crear contenedor principal
    GtkWidget *caja_v = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(ventana), caja_v);

    // Crear listado de cajas
    GtkWidget *treeview = gtk_tree_view_new();
    gtk_box_pack_start(GTK_BOX(caja_v), treeview, TRUE, TRUE, 0);
    cargar_cajas(treeview);

    // Crear botones
    GtkWidget *boton_agregar = gtk_button_new_with_label("Agregar Caja");
    GtkWidget *boton_modificar = gtk_button_new_with_label("Modificar Caja");
    GtkWidget *boton_eliminar = gtk_button_new_with_label("Eliminar Caja");
    GtkWidget *boton_registrar_venta = gtk_button_new_with_label("Cajas");
    GtkWidget *boton_cerrar = gtk_button_new_with_label("Cerrar");

    // Contenedor para los botones
    GtkWidget *caja_h = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5); // Cambiar a orientación vertical
    gtk_widget_set_halign(caja_h, GTK_ALIGN_CENTER);              // Centrar el contenedor de botones horizontalmente
    gtk_widget_set_valign(caja_h, GTK_ALIGN_CENTER);              // Centrar el contenedor de botones verticalmente

    gtk_box_pack_start(GTK_BOX(caja_h), boton_agregar, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(caja_h), boton_modificar, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(caja_h), boton_eliminar, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(caja_h), boton_registrar_venta, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(caja_h), boton_cerrar, TRUE, TRUE, 0);

    // Centrar el contenedor de botones en la ventana
    gtk_widget_set_halign(caja_v, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(caja_v, GTK_ALIGN_CENTER);
    gtk_box_pack_start(GTK_BOX(caja_v), caja_h, TRUE, TRUE, 0);

    // Conectar botones a sus funciones
    g_signal_connect(boton_agregar, "clicked", G_CALLBACK(on_agregar_caja), ventana);
    g_signal_connect(boton_modificar, "clicked", G_CALLBACK(on_modificar_caja), ventana);
    g_signal_connect(boton_eliminar, "clicked", G_CALLBACK(on_eliminar_caja), ventana);
    g_signal_connect(boton_registrar_venta, "clicked", G_CALLBACK(on_registrar_venta), ventana);
    g_signal_connect(boton_cerrar, "clicked", G_CALLBACK(cerrar_ventana), ventana);

    // Mostrar todo
    gtk_widget_show_all(ventana);
    gtk_main();
}