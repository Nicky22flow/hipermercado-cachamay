#include "facturas.h"
#include "clientes.h"  
#include "productos.h"
#include "control_cajas.h"
#include <gtk/gtk.h>
#include <stdio.h>
#include <time.h>


void mostrarVentanaFactura(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *vbox, *button_crear, *button_modificar, *button_eliminar, *button_mostrar;

    // Crear una nueva ventana
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Gestión de Facturas");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    // Crear un contenedor vertical
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    // Botón para crear factura
    button_crear = gtk_button_new_with_label("Crear Factura");
    g_signal_connect(button_crear, "clicked", G_CALLBACK(on_registrar_venta), window);
    gtk_box_pack_start(GTK_BOX(vbox), button_crear, TRUE, TRUE, 0);

    // Botón para modificar factura
    button_modificar = gtk_button_new_with_label("Modificar Factura");
    g_signal_connect(button_modificar, "clicked", G_CALLBACK(modificar_factura), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_modificar, TRUE, TRUE, 0);

    // Botón para eliminar factura
    button_eliminar = gtk_button_new_with_label("Eliminar Factura");
    g_signal_connect(button_eliminar, "clicked", G_CALLBACK(eliminar_factura), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_eliminar, TRUE, TRUE, 0);

    // Botón para mostrar facturas
    button_mostrar = gtk_button_new_with_label("Mostrar Facturas");
    g_signal_connect(button_mostrar, "clicked", G_CALLBACK(mostrar_facturas), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), button_mostrar, TRUE, TRUE, 0);

    gtk_widget_show_all(window);
}

void guardarFacturaEnArchivo(Factura factura, const char *archivo) {
    FILE *file = fopen(archivo, "a");
    if (!file) {
        perror("Error al abrir el archivo de facturas");
        return;
    }

    fprintf(file, "Hipermercado Cachamay\n");
    fprintf(file, "RIF: J-123456789\n");
    fprintf(file, "Teléfono: 04140463588\n\n");
    fprintf(file, "Factura N°: %d\n", factura.numero_factura);

    // Obtener la fecha actual
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    snprintf(factura.fecha, sizeof(factura.fecha), "%02d-%02d-%d %02d:%02d:%02d", 
             tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);
    fprintf(file, "Fecha: %s\n", factura.fecha);

    fprintf(file, "Cliente: %s\n", factura.cliente.nombre);
    fprintf(file, "Cédula: %s\n", factura.cliente.cedula);
    fprintf(file, "Teléfono: %s\n", factura.cliente.telefono);
    fprintf(file, "Dirección: %s\n\n", factura.cliente.direccion);

    fprintf(file, "Productos:\n");
    for (int i = 0; i < factura.num_productos; i++) {
        Producto producto = factura.productos[i];
        fprintf(file, "%d x %s @ Bs %.2f\n", producto.cantidad, producto.nombre, producto.precio);
    }

    fprintf(file, "\nPorcentaje de impuesto (IVA): %.2f%%\n", factura.impuesto);
    fprintf(file, "Monto total (con impuesto): Bs %.2f\n", factura.monto_total);
    fprintf(file, "---------------------------------------\n");

    fclose(file);
}

void mostrarFormatoFactura(Factura factura) {
    GtkWidget *window, *vbox, *label;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Formato de Factura");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    char formato[4096]; // Aumentar el tamaño del buffer
    snprintf(formato, sizeof(formato),
        "Hipermercado Cachamay\n"
        "RIF: J-123456789\n"
        "Teléfono: 04140463588\n\n"
        "Factura N°: %d\n"
        "Fecha: %s\n"
        "Cliente: %s\n"
        "Cédula: %s\n"
        "Teléfono: %s\n"
        "Dirección: %s\n\n"
        "Productos:\n",
        factura.numero_factura,
        factura.fecha,
        factura.cliente.nombre,
        factura.cliente.cedula,
        factura.cliente.telefono,
        factura.cliente.direccion);

    for (int i = 0; i < factura.num_productos; i++) {
        char producto[256];
        snprintf(producto, sizeof(producto), "%d x %s @ Bs %.2f\n",
                 factura.productos[i].cantidad,
                 factura.productos[i].nombre,
                 factura.productos[i].precio);
        strncat(formato, producto, sizeof(formato) - strlen(formato) - 1);
    }

    char totales[256];
    snprintf(totales, sizeof(totales),
        "\nPorcentaje de impuesto (IVA): %.2f%%\n"
        "Monto total (con impuesto): Bs %.2f\n"
        "---------------------------------------\n",
        factura.impuesto,
        factura.monto_total);

    strncat(formato, totales, sizeof(formato) - strlen(formato) - 1);

    label = gtk_label_new(formato);
    gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);

    gtk_widget_show_all(window);
}

void modificar_factura(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry_numero, *entry_cliente, *entry_fecha, *entry_impuesto, *entry_monto;
    dialog = gtk_dialog_new_with_buttons("Modificar Factura", GTK_WINDOW(data), GTK_DIALOG_MODAL, "Aceptar", GTK_RESPONSE_OK, "Cancelar", GTK_RESPONSE_CANCEL, NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    entry_numero = gtk_entry_new();
    entry_cliente = gtk_entry_new();
    entry_fecha = gtk_entry_new();
    entry_impuesto = gtk_entry_new();
    entry_monto = gtk_entry_new();

    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_numero), "Número de factura");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_cliente), "Cliente");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_fecha), "Fecha");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_impuesto), "Impuesto");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_monto), "Monto total");

    gtk_box_pack_start(GTK_BOX(content_area), entry_numero, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_cliente, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_fecha, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_impuesto, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_monto, FALSE, FALSE, 5);

    gtk_widget_show_all(dialog);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        int numero_factura = atoi(gtk_entry_get_text(GTK_ENTRY(entry_numero)));
        char *cliente = g_strdup(gtk_entry_get_text(GTK_ENTRY(entry_cliente)));
        char *fecha = g_strdup(gtk_entry_get_text(GTK_ENTRY(entry_fecha)));
        float impuesto = atof(gtk_entry_get_text(GTK_ENTRY(entry_impuesto)));
        float monto_total = atof(gtk_entry_get_text(GTK_ENTRY(entry_monto)));

        // Leer las facturas desde el archivo
        Factura facturas[100];
        int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

        // Buscar la factura por número
        for (int i = 0; i < num_facturas; i++) {
            if (facturas[i].numero_factura == numero_factura) {
                // Modificar los datos de la factura
                strcpy(facturas[i].cliente.nombre, cliente);
                strcpy(facturas[i].fecha, fecha);
                facturas[i].impuesto = impuesto;
                facturas[i].monto_total = monto_total;
                break;
            }
        }

        // Guardar las facturas modificadas en el archivo
        guardarFacturasEnArchivo("facturas.txt", facturas, num_facturas);

        g_free(cliente);
        g_free(fecha);
    }

    gtk_widget_destroy(dialog);
}

void eliminar_factura(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry_numero;
    dialog = gtk_dialog_new_with_buttons("Eliminar Factura", GTK_WINDOW(data), GTK_DIALOG_MODAL, "Aceptar", GTK_RESPONSE_OK, "Cancelar", GTK_RESPONSE_CANCEL, NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    entry_numero = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_numero), "Número de factura");
    gtk_box_pack_start(GTK_BOX(content_area), entry_numero, FALSE, FALSE, 5);

    gtk_widget_show_all(dialog);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        int numero_factura = atoi(gtk_entry_get_text(GTK_ENTRY(entry_numero)));

        // Leer las facturas desde el archivo
        Factura facturas[100];
        int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

        // Buscar y eliminar la factura por número
        int i, j;
        for (i = 0; i < num_facturas; i++) {
            if (facturas[i].numero_factura == numero_factura) {
                for (j = i; j < num_facturas - 1; j++) {
                    facturas[j] = facturas[j + 1];
                }
                num_facturas--;
                break;
            }
        }

        // Guardar las facturas modificadas en el archivo
        guardarFacturasEnArchivo("facturas.txt", facturas, num_facturas);
    }

    gtk_widget_destroy(dialog);
}

void mostrar_facturas(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *vbox, *scrolled_window, *grid;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Lista de Facturas");
    gtk_window_set_default_size(GTK_WINDOW(window), 600, 400);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0);

    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10);
    gtk_container_add(GTK_CONTAINER(scrolled_window), grid);

    // Leer las facturas desde el archivo
    Factura facturas[100];
    int num_facturas = leerFacturasDesdeArchivo("facturas.txt", facturas);

    // Encabezados de la tabla
    const char *headers[] = {"Número", "Cliente", "Fecha", "Impuesto", "Monto Total"};
    int num_headers = sizeof(headers) / sizeof(headers[0]);

    for (int col = 0; col < num_headers; col++) {
        GtkWidget *label = gtk_label_new(headers[col]);
        gtk_grid_attach(GTK_GRID(grid), label, col, 0, 1, 1);
    }

    // Mostrar cada factura
    for (int row = 1; row <= num_facturas; row++) {
        char numero_str[10], impuesto_str[10], monto_str[10];
        snprintf(numero_str, sizeof(numero_str), "%d", facturas[row - 1].numero_factura);
        snprintf(impuesto_str, sizeof(impuesto_str), "%.2f", facturas[row - 1].impuesto);
        snprintf(monto_str, sizeof(monto_str), "%.2f", facturas[row - 1].monto_total);

        const char *datos[] = {numero_str, facturas[row - 1].cliente.nombre, facturas[row - 1].fecha, impuesto_str, monto_str};
        for (int col = 0; col < num_headers; col++) {
            GtkWidget *label = gtk_label_new(datos[col]);
            gtk_grid_attach(GTK_GRID(grid), label, col, row, 1, 1);
        }
    }

    gtk_widget_show_all(window);
}

int leerFacturasDesdeArchivo(const char *archivo, Factura *facturas) {
    FILE *file = fopen(archivo, "r");
    if (!file) {
        perror("Error al abrir el archivo de facturas");
        return 0;
    }

    int i = 0;
    while (fscanf(file, "Factura N°: %d\nFecha: %19[^\n]\nCliente: %49[^\n]\nCédula: %19[^\n]\nTeléfono: %11[^\n]\nDirección: %99[^\n]\n\nProductos:\n",
                  &facturas[i].numero_factura, facturas[i].fecha, facturas[i].cliente.nombre, facturas[i].cliente.cedula,
                  facturas[i].cliente.telefono, facturas[i].cliente.direccion) == 6) {
        // Leer productos
        facturas[i].num_productos = 0;
        while (fscanf(file, "%d x %49[^\n] @ Bs %f\n", &facturas[i].productos[facturas[i].num_productos].cantidad,
                       facturas[i].productos[facturas[i].num_productos].nombre,
                       &facturas[i].productos[facturas[i].num_productos].precio) == 3) {
            facturas[i].num_productos++;
        }

        // Leer totales
        fscanf(file, "\nPorcentaje de impuesto (IVA): %f%%\nMonto total (con impuesto): Bs %f\n---------------------------------------\n",
               &facturas[i].impuesto, &facturas[i].monto_total);
        i++;
    }

    fclose(file);
    return i;
}

void guardarFacturasEnArchivo(const char *archivo, Factura *facturas, int num_facturas) {
    FILE *file = fopen(archivo, "w");
    if (!file) {
        perror("Error al abrir el archivo de facturas");
        return;
    }

    for (int i = 0; i < num_facturas; i++) {
        fprintf(file, "Hipermercado Cachamay\n");
        fprintf(file, "RIF: J-123456789\n");
        fprintf(file, "Teléfono: 04140463588\n\n");
        fprintf(file, "Factura N°: %d\n", facturas[i].numero_factura);
        fprintf(file, "Fecha: %s\n", facturas[i].fecha);
        fprintf(file, "Cliente: %s\n", facturas[i].cliente.nombre);
        fprintf(file, "Cédula: %s\n", facturas[i].cliente.cedula);
        fprintf(file, "Teléfono: %s\n", facturas[i].cliente.telefono);
        fprintf(file, "Dirección: %s\n\n", facturas[i].cliente.direccion);

        fprintf(file, "Productos:\n");
        for (int j = 0; j < facturas[i].num_productos; j++) {
            fprintf(file, "%d x %s @ Bs %.2f\n", facturas[i].productos[j].cantidad, facturas[i].productos[j].nombre, facturas[i].productos[j].precio);
        }

        fprintf(file, "\nPorcentaje de impuesto (IVA): %.2f%%\n", facturas[i].impuesto);
        fprintf(file, "Monto total (con impuesto): Bs %.2f\n", facturas[i].monto_total);
        fprintf(file, "---------------------------------------\n");
    }

    fclose(file);
}