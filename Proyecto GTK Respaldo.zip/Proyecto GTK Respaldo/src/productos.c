//productos.c
#include "productos.h" // Incluir el archivo de cabecera para la estructura Empleado y funciones relacionadas
#include <stdio.h>     // Incluir la biblioteca estándar de entrada/salida
#include <stdlib.h>    // Incluir la biblioteca estándar de utilidades
#include <string.h>    // Incluir la biblioteca estándar de manejo de cadenas
#include <ctype.h>     // Incluir la biblioteca estándar de funciones de caracteres


void crear_ventana_productos(GtkWidget *widget, gpointer data) {
    GtkWidget *window; // Puntero a la ventana principal
    GtkWidget *box; // Puntero al contenedor vertical para los botones
    GtkWidget *button; // Puntero a los botones de la interfaz

    // Crear una nueva ventana de la aplicación
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Gestión de Productos"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300); // Establecer el tamaño predeterminado de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana en la pantalla

    GdkRGBA color;
    gdk_rgba_parse(&color, "#387647"); //Color de la ventana   
    G_GNUC_BEGIN_IGNORE_DEPRECATIONS
    gtk_widget_override_background_color(GTK_WIDGET(window), GTK_STATE_FLAG_NORMAL, &color);
    G_GNUC_BEGIN_IGNORE_DEPRECATIONS

    // Crear un GtkBox vertical para centrar los botones
    box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_set_halign(box, GTK_ALIGN_CENTER); // Centrar horizontalmente el GtkBox
    gtk_widget_set_valign(box, GTK_ALIGN_CENTER); // Centrar verticalmente el GtkBox
    gtk_container_add(GTK_CONTAINER(window), box); // Agregar el GtkBox a la ventana

    // Botón para registrar un cliente
    button = gtk_button_new_with_label("Registrar Producto");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_formulario_registro_productos), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Botón para modificar un cliente
    button = gtk_button_new_with_label("Modificar Producto");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_formulario_modificar_producto), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Botón para eliminar un cliente
    button = gtk_button_new_with_label("Eliminar Producto");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_formulario_eliminar_producto), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Botón para buscar un cliente
    button = gtk_button_new_with_label("Mostrar Productos");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_productos), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Mostrar todos los widgets en la ventana
    gtk_widget_show_all(window);
}

void mostrar_formulario_registro_productos(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog;  //puntero a GtkWidget para el diálogo
    GtkWidget *content_area;    //puntero a GtkWidget para el área de contenido del diálogo
    GtkWidget *grid;    //puntero a GtkWidget para la cuadrícula dentro del área de contenido
    GtkWidget *label;   //puntero a GtkWidget para una etiqueta dentro de la cuadrícula
    GtkWidget **entrys = g_malloc(sizeof(GtkWidget *) * 4); // Array para almacenar los campos de entrada

    // Crear un nuevo cuadro de diálogo con botones "Cancelar" y "Registrar"
    dialog = gtk_dialog_new_with_buttons("Registrar Producto",
                                        GTK_WINDOW(gtk_widget_get_toplevel(widget)),
                                        GTK_DIALOG_MODAL,
                                        "_Cancelar", GTK_RESPONSE_CANCEL,
                                        "Registrar", GTK_RESPONSE_ACCEPT,
                                        NULL);
    gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo

    // Obtener el área de contenido del cuadro de diálogo
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    grid = gtk_grid_new(); // Crear una nueva cuadrícula para organizar los widgets
    gtk_container_add(GTK_CONTAINER(content_area), grid); // Agregar la cuadrícula al área de contenido

    // Crear y agregar los campos de entrada al grid
    const char *labels[] = {"Código", "Nombre", "Precio", "Cantidad"};
    for (int i = 0; i < 4; i++) {
        label = gtk_label_new(labels[i]); // Crear una nueva etiqueta para cada campo
        entrys[i] = gtk_entry_new(); // Crear un nuevo campo de entrada
        gtk_grid_attach(GTK_GRID(grid), label, 0, i, 1, 1); // Agregar la etiqueta a la cuadrícula
        gtk_grid_attach(GTK_GRID(grid), entrys[i], 1, i, 1, 1); // Agregar el campo de entrada a la cuadrícula
    }

    // Conectar la señal "response" del diálogo a la función guardar_producto_callback
    g_signal_connect(dialog, "response", G_CALLBACK(guardar_producto_callback), entrys);

    gtk_widget_show_all(dialog); // Mostrar todos los widgets en el cuadro de diálogo
}

void mostrar_formulario_modificar_producto(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *grid, *boton_buscar, *boton_guardar; // Declaración de widgets para la ventana, cuadrícula y botones
    GtkWidget **entrys = g_malloc0(sizeof(GtkWidget *) * 4); // Array para almacenar los campos de entrada
    GtkWidget *label; // Declaración de widget para las etiquetas
    const char *labels[] = {"Código", "Nombre", "Precio", "Cantidad"}; // Etiquetas para los campos de entrada

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL); // Crear una nueva ventana
    gtk_window_set_title(GTK_WINDOW(window), "Modificar Producto"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300); // Establecer el tamaño predeterminado de la ventana
    gtk_container_set_border_width(GTK_CONTAINER(window), 10); // Establecer el ancho del borde de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana

    grid = gtk_grid_new(); // Crear una nueva cuadrícula para organizar los widgets
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5); // Establecer el espaciado entre filas
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5); // Establecer el espaciado entre columnas
    gtk_container_add(GTK_CONTAINER(window), grid); // Agregar la cuadrícula al contenedor de la ventana

    for (int i = 0; i < 4; i++) { // Iterar sobre las etiquetas y campos de entrada
        label = gtk_label_new(labels[i]); // Crear una nueva etiqueta
        entrys[i] = gtk_entry_new(); // Crear un nuevo campo de entrada
        gtk_grid_attach(GTK_GRID(grid), label, 0, i, 1, 1); // Agregar la etiqueta a la cuadrícula
        gtk_grid_attach(GTK_GRID(grid), entrys[i], 1, i, 1, 1); // Agregar el campo de entrada a la cuadrícula
    }

    // Botón para buscar
    boton_buscar = gtk_button_new_with_label("Buscar"); // Crear un nuevo botón con la etiqueta "Buscar"
    gtk_grid_attach(GTK_GRID(grid), boton_buscar, 2, 0, 1, 1); // Agregar el botón a la cuadrícula
    g_signal_connect(boton_buscar, "clicked", G_CALLBACK(buscar_producto_callback), entrys); // Conectar la señal "clicked" al callback

    // Botón para guardar cambios
    boton_guardar = gtk_button_new_with_label("Guardar Cambios"); // Crear un nuevo botón con la etiqueta "Guardar Cambios"
    gtk_grid_attach(GTK_GRID(grid), boton_guardar, 1, 4, 1, 1); // Agregar el botón a la cuadrícula
    g_signal_connect(boton_guardar, "clicked", G_CALLBACK(guardar_producto_modificado), entrys); // Conectar la señal "clicked" al callback

    gtk_widget_show_all(window); // Mostrar todos los widgets en la ventana
}

void mostrar_formulario_eliminar_producto(GtkWidget *widget, gpointer data) {
    GtkWidget *window; // Puntero a la ventana principal
    GtkWidget *grid; // Puntero a la cuadrícula para organizar los widgets
    GtkWidget *label_codigo; // Puntero a la etiqueta para el campo de código
    GtkWidget *entry_codigo; // Puntero al campo de entrada para el código
    GtkWidget *button_eliminar; // Puntero al botón de eliminar

    // Crear una nueva ventana
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Eliminar Producto"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 300, 50); // Establecer el tamaño predeterminado de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana

    // Crear una nueva cuadrícula y agregarla a la ventana
    grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    // Crear una etiqueta para el campo de código y agregarla a la cuadrícula
    label_codigo = gtk_label_new("Código:");
    gtk_grid_attach(GTK_GRID(grid), label_codigo, 0, 0, 1, 1);

    // Crear un campo de entrada para el código y agregarlo a la cuadrícula
    entry_codigo = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grid), entry_codigo, 1, 0, 2, 1);

    // Crear un botón de eliminar y agregarlo a la cuadrícula
    button_eliminar = gtk_button_new_with_label("Eliminar");
    gtk_grid_attach(GTK_GRID(grid), button_eliminar, 3, 0, 1, 1);

    // Conectar el botón "Eliminar" al callback
    g_signal_connect(button_eliminar, "clicked", G_CALLBACK(eliminar_producto_callback), entry_codigo);

    // Mostrar todos los widgets en la ventana
    gtk_widget_show_all(window);
}

void mostrar_productos(GtkWidget *widget, gpointer data) {
    // Crear una nueva ventana
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Lista de Productos"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 500, 200); // Establecer el tamaño predeterminado de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana

    // Crear un contenedor vertical
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox); // Agregar el contenedor vertical a la ventana

    // Crear un contenedor con desplazamiento para los productos
    GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0); // Agregar el contenedor con desplazamiento al contenedor vertical

    // Crear una tabla para mostrar los datos de los productos
    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5); // Establecer el espaciado entre filas
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10); // Establecer el espaciado entre columnas
    gtk_container_add(GTK_CONTAINER(scrolled_window), grid); // Agregar la tabla al contenedor con desplazamiento

    // Encabezados de la tabla
    const char *headers[] = {"Código", "Nombre", "Precio", "Cantidad"};
    int num_headers = sizeof(headers) / sizeof(headers[0]); // Calcular el número de encabezados

    for (int col = 0; col < num_headers; col++) {
        GtkWidget *label = gtk_label_new(headers[col]); // Crear un label para cada encabezado
        gtk_grid_attach(GTK_GRID(grid), label, col * 2, 0, 1, 1); // Agregar el label a la tabla
        if (col < num_headers - 1) {
            gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_VERTICAL), col * 2 + 1, 0, 1, 1); // Agregar un separador vertical
        }
    }

    // Leer productos desde el archivo
    FILE *file_productos = fopen("productos.txt", "r");
    if (!file_productos) { // Verificar si se pudo abrir el archivo de productos
        GtkWidget *error_dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                        GTK_BUTTONS_OK,
                                                        "Error: No se pudo abrir el archivo de productos.");
        gtk_dialog_run(GTK_DIALOG(error_dialog)); // Mostrar un cuadro de diálogo de error
        gtk_widget_destroy(error_dialog); // Destruir el cuadro de diálogo de error
        return;
    }

    // Leer y mostrar cada producto
    char linea[512];
    int row = 1;
    while (fgets(linea, sizeof(linea), file_productos)) { // Leer cada línea del archivo
        Producto producto;
        sscanf(linea, "%[^,],%[^,],%f,%d",
            producto.codigo, producto.nombre, &producto.precio,
            &producto.cantidad); // Parsear los datos del producto

        // Convertir los valores de precio y cantidad a cadenas de caracteres
        char precio_str[20];
        char cantidad_str[20];
        sprintf(precio_str, "%.2f", producto.precio);
        sprintf(cantidad_str, "%d", producto.cantidad);

        // Crear etiquetas para cada campo y agregar al grid
        const char *datos[] = {producto.codigo, producto.nombre, precio_str, cantidad_str};
        for (int col = 0; col < num_headers; col++) {
            GtkWidget *label = gtk_label_new(datos[col]); // Crear un label para cada dato
            gtk_grid_attach(GTK_GRID(grid), label, col * 2, row, 1, 1); // Agregar el label a la tabla
            if (col < num_headers - 1) {
                gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_VERTICAL), col * 2 + 1, row, 1, 1); // Agregar un separador vertical
            }
        }

        // Separador horizontal
        gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_HORIZONTAL), 0, row + 1, num_headers * 2 - 1, 1); // Agregar un separador horizontal

        row += 2; // Incrementar la fila
    }
    fclose(file_productos); // Cerrar el archivo de productos

    // Mostrar la ventana con todos los datos
    gtk_widget_show_all(window);
}

// Callback para guardar un producto
void guardar_producto_callback(GtkDialog *dialog, gint response_id, gpointer user_data)
{
    GtkWidget **entrys = (GtkWidget **)user_data; // Obtener los widgets de entrada

    if (response_id == GTK_RESPONSE_ACCEPT)
    {                   // Si la respuesta es aceptar
        Producto producto; // Crear una estructura Producto

        // Obtener los valores de los campos de entrada
        const char *codigo = gtk_entry_get_text(GTK_ENTRY(entrys[0]));    // Obtener texto del código
        const char *nombre = gtk_entry_get_text(GTK_ENTRY(entrys[1]));    // Obtener texto del nombre
        const char *precio_str = gtk_entry_get_text(GTK_ENTRY(entrys[2]));  // Obtener texto del precio
        const char *cantidad_str = gtk_entry_get_text(GTK_ENTRY(entrys[3])); // Obtener texto de la cantidad

        // Copiar los valores a la estructura Producto
        strncpy(producto.codigo, codigo, sizeof(producto.codigo) - 1);       // Copiar el código
        producto.codigo[sizeof(producto.codigo) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
        strncpy(producto.nombre, nombre, sizeof(producto.nombre) - 1);       // Copiar el nombre
        producto.nombre[sizeof(producto.nombre) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
        producto.precio = atof(precio_str); // Convertir y copiar el precio
        producto.cantidad = atoi(cantidad_str); // Convertir y copiar la cantidad

        // Validar campos y registrar el producto
        if (validar_campos_producto(producto) && registrar_producto("productos.txt", producto))
        {                                                                          // Si los campos son válidos y el registro es exitoso
            GtkWidget *success_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog), // Crear un diálogo de éxito
                                                               GTK_DIALOG_MODAL,
                                                               GTK_MESSAGE_INFO,
                                                               GTK_BUTTONS_OK,
                                                               "Producto registrado correctamente.");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(success_dialog));                      // Mostrar el diálogo de éxito
            gtk_widget_destroy(success_dialog);                              // Destruir el diálogo de éxito
            gtk_widget_destroy(GTK_WIDGET(dialog));                          // Cerrar el diálogo solo si el registro es exitoso
            g_free(entrys);                                                  // Liberar la memoria de las entradas solo si el registro es exitoso
        }
    }
    else
    {                                           // Si la respuesta no es aceptar
        gtk_widget_destroy(GTK_WIDGET(dialog)); // Cerrar el diálogo si se cancela
        g_free(entrys);                         // Liberar la memoria de las entradas si se cancela
    }
}

int registrar_producto(const char *archivo, Producto producto)
{
    // Validar los campos del producto
    if (!validar_campos_producto(producto))
    {
        return 0; // Fallo en la validación
    }

    // Verificar si el código ya está registrado
    if (codigo_duplicado_producto(archivo, producto.codigo))
    {
        // Mostrar un mensaje de advertencia si el código ya está registrado
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "El código ya está registrado.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return 0; // Fallo
    }

    // Abrir el archivo en modo de adición
    FILE *file = fopen(archivo, "a");
    if (!file)
        return 0; // Fallo al abrir el archivo

    // Escribir los datos del producto en el archivo
    fprintf(file, "%s,%s,%.2f,%d\n",
            producto.codigo, producto.nombre, producto.precio,
            producto.cantidad);
    fclose(file); // Cerrar el archivo
    return 1;     // Éxito
}

int validar_campos_producto(Producto producto)
{
    // Validar código
    if (strlen(producto.codigo) == 0)
    { // Verificar si el campo 'Código' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Código' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }

    // Validar nombre
    if (strlen(producto.nombre) == 0)
    { // Verificar si el campo 'Nombre' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Nombre' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }

    // Validar precio
    if (producto.precio <= 0)
    { // Verificar si el campo 'Precio' es menor o igual a cero
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Precio' debe ser mayor a cero.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }

    // Validar cantidad
    if (producto.cantidad < 0)
    { // Verificar si el campo 'Cantidad' es negativo
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Cantidad' no puede ser negativo.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }

    return 1; // Validación exitosa
}

int codigo_duplicado_producto(const char *archivo, const char *codigo)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
        return 0; // Si el archivo no existe, no hay duplicados

    char linea[256]; // Buffer para leer cada línea del archivo
    while (fgets(linea, sizeof(linea), file))
    {                                             // Leer línea por línea
        char codigo_existente[8];                 // Buffer para almacenar el código existente
        sscanf(linea, "%[^,]", codigo_existente); // Extraer el código de la línea
        if (strcmp(codigo, codigo_existente) == 0)
        {                 // Comparar el código con el código existente
            fclose(file); // Cerrar el archivo
            return 1;     // Código encontrado, hay duplicado
        }
    }
    fclose(file); // Cerrar el archivo
    return 0;     // No se encontró duplicado
}

int modificar_producto(const char *archivo, const char *codigo, Producto nuevo_producto)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
        return 0; // Si no se puede abrir el archivo, retornar 0

    FILE *temp = fopen("temp.txt", "w"); // Crear un archivo temporal en modo escritura
    if (!temp)
    {                 // Si no se puede crear el archivo temporal
        fclose(file); // Cerrar el archivo original
        return 0;     // Retornar 0
    }

    char linea[512];    // Buffer para leer cada línea del archivo
    int encontrado = 0; // Variable para indicar si se encontró el producto

    while (fgets(linea, sizeof(linea), file))
    {                      // Leer línea por línea del archivo
        Producto producto; // Crear una estructura Producto
        sscanf(linea, "%[^,],%[^,],%f,%d",
               producto.codigo, producto.nombre, &producto.precio,
               &producto.cantidad); // Extraer los datos del producto de la línea

        if (strcmp(producto.codigo, codigo) == 0)
        {                   // Si el código coincide con el buscado
            encontrado = 1; // Marcar como encontrado
            // Escribir los datos del nuevo producto en el archivo temporal
            fprintf(temp, "%s,%s,%.2f,%d\n",
                    nuevo_producto.codigo, nuevo_producto.nombre, nuevo_producto.precio,
                    nuevo_producto.cantidad);
        }
        else
        {                       // Si el código no coincide
            fputs(linea, temp); // Escribir la línea original en el archivo temporal
        }
    }

    fclose(file);                // Cerrar el archivo original
    fclose(temp);                // Cerrar el archivo temporal
    remove(archivo);             // Eliminar el archivo original
    rename("temp.txt", archivo); // Renombrar el archivo temporal al nombre original

    return encontrado; // Retornar si se encontró el producto
}

void buscar_producto_callback(GtkWidget *widget, gpointer data)
{
    GtkWidget **entrys = (GtkWidget **)data; // Obtener los widgets de entrada

    // Validar que el campo de código sea un GtkEntry
    if (!GTK_IS_ENTRY(entrys[0]))
    {
        g_warning("El campo de código no es un GtkEntry válido."); // Mostrar advertencia si no es un GtkEntry válido
        return;                                                    // Salir de la función
    }

    const char *codigo = gtk_entry_get_text(GTK_ENTRY(entrys[0])); // Obtener el texto del código
    Producto producto;                                             // Crear una estructura Producto

    // Buscar el producto por código
    if (buscar_producto("productos.txt", codigo, &producto))
    {
        // Si se encuentra el producto, llenar los campos con sus datos
        gtk_entry_set_text(GTK_ENTRY(entrys[1]), producto.nombre);           // Establecer el nombre
        char precio_str[20];
        snprintf(precio_str, sizeof(precio_str), "%.2f", producto.precio);   // Convertir el precio a cadena
        gtk_entry_set_text(GTK_ENTRY(entrys[2]), precio_str);                // Establecer el precio
        char cantidad_str[20];
        snprintf(cantidad_str, sizeof(cantidad_str), "%d", producto.cantidad); // Convertir la cantidad a cadena
        gtk_entry_set_text(GTK_ENTRY(entrys[3]), cantidad_str);              // Establecer la cantidad
    }
    else
    {
        // Si no se encuentra el producto, mostrar un mensaje de error
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Producto no encontrado.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar el diálogo de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
    }
}

// Función para buscar un producto por código
int buscar_producto(const char *archivo, const char *codigo, Producto *producto)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
        return 0; // Si no se puede abrir el archivo, retornar 0

    char buffer[512]; // Buffer para leer cada línea del archivo
    while (fgets(buffer, sizeof(buffer), file))
    { // Leer línea por línea del archivo
        // Extraer los datos del producto de la línea
        sscanf(buffer, "%[^,],%[^,],%f,%d",
               producto->codigo, producto->nombre, &producto->precio,
               &producto->cantidad);

        if (strcmp(producto->codigo, codigo) == 0)
        {                 // Comparar el código con el código buscado
            fclose(file); // Cerrar el archivo
            return 1;     // Retornar 1 si se encuentra el producto
        }
    }
    fclose(file); // Cerrar el archivo
    return 0;     // Retornar 0 si no se encuentra el producto
}

void guardar_producto_modificado(GtkWidget *widget, gpointer data)
{
    GtkWidget **entrys = (GtkWidget **)data; // Obtener los widgets de entrada

    // Validar que todos los widgets sean GtkEntry
    for (int i = 0; i < 4; i++)
    {
        if (!GTK_IS_ENTRY(entrys[i]))
        {                                                                       // Si no es un GtkEntry válido
            g_warning("El campo en el índice %d no es un GtkEntry válido.", i); // Mostrar advertencia
            return;                                                             // Salir de la función
        }
    }

    Producto producto;                                             // Crear una estructura Producto
    const char *codigo = gtk_entry_get_text(GTK_ENTRY(entrys[0])); // Obtener texto del código

    if (!codigo || strlen(codigo) == 0)
    { // Si el código está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Código' está vacío."); // Crear un diálogo de error
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                                    // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                                 // Mostrar el diálogo de error
        gtk_widget_destroy(dialog);                                                                         // Destruir el diálogo de error
        return;                                                                                             // Salir de la función
    }

    // Obtener los valores de los campos de entrada
    const char *nombre = gtk_entry_get_text(GTK_ENTRY(entrys[1]));    // Obtener texto del nombre
    const char *precio_str = gtk_entry_get_text(GTK_ENTRY(entrys[2]));  // Obtener texto del precio
    const char *cantidad_str = gtk_entry_get_text(GTK_ENTRY(entrys[3])); // Obtener texto de la cantidad

    // Copiar los valores a la estructura Producto
    strncpy(producto.codigo, codigo, sizeof(producto.codigo) - 1);       // Copiar el código
    producto.codigo[sizeof(producto.codigo) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
    strncpy(producto.nombre, nombre, sizeof(producto.nombre) - 1);       // Copiar el nombre
    producto.nombre[sizeof(producto.nombre) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
    producto.precio = atof(precio_str); // Convertir y copiar el precio
    producto.cantidad = atoi(cantidad_str); // Convertir y copiar la cantidad

    if (modificar_producto("productos.txt", codigo, producto))
    { // Si la modificación es exitosa
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "Producto modificado correctamente."); // Crear un diálogo de éxito
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                                  // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                               // Mostrar el diálogo de éxito
        gtk_widget_destroy(dialog);                                                                       // Destruir el diálogo de éxito
    }
    else
    { // Si hay un error en la modificación
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error al modificar el producto."); // Crear un diálogo de error
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                              // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                           // Mostrar el diálogo de error
        gtk_widget_destroy(dialog);                                                                   // Destruir el diálogo de error
    }
}

int eliminar_producto(const char *archivo, const char *codigo)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
    {
        perror("Error al abrir el archivo"); // Mostrar error si no se puede abrir el archivo
        return 0;                            // Retornar 0 indicando fallo
    }

    FILE *temp = fopen("temp.txt", "w"); // Crear un archivo temporal en modo escritura
    if (!temp)
    {
        perror("Error al crear el archivo temporal"); // Mostrar error si no se puede crear el archivo temporal
        fclose(file);                                 // Cerrar el archivo original
        return 0;                                     // Retornar 0 indicando fallo
    }

    char buffer[512];   // Buffer para leer cada línea del archivo
    int encontrado = 0; // Variable para indicar si se encontró el producto

    while (fgets(buffer, sizeof(buffer), file))
    {                                             // Leer línea por línea del archivo
        char codigo_actual[8];                    // Buffer para almacenar el código actual
        sscanf(buffer, "%7[^,]", codigo_actual);  // Extraer el código (hasta la primera coma)

        if (strcmp(codigo_actual, codigo) == 0)
        {
            encontrado = 1; // Marcar como encontrado si el código coincide
        }
        else
        {
            fputs(buffer, temp); // Copiar las líneas no coincidentes al archivo temporal
        }
    }

    fclose(file); // Cerrar el archivo original
    fclose(temp); // Cerrar el archivo temporal

    // Reemplazar el archivo original solo si se encontró el producto
    if (encontrado)
    {
        remove(archivo);             // Eliminar el archivo original
        rename("temp.txt", archivo); // Renombrar el archivo temporal al nombre original
    }
    else
    {
        remove("temp.txt"); // Eliminar el archivo temporal si no se encontró nada
    }

    return encontrado; // Retornar si se encontró el producto
}

void eliminar_producto_callback(GtkWidget *widget, gpointer data)
{
    GtkWidget *entry_codigo = GTK_WIDGET(data); // Obtener el GtkEntry pasado como "data"

    if (!GTK_IS_ENTRY(entry_codigo))
    { // Validar que sea un GtkEntry
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "El campo Código no es válido."); // Crear un diálogo de advertencia
        gtk_dialog_run(GTK_DIALOG(dialog));                                                          // Mostrar el diálogo de advertencia
        gtk_widget_destroy(dialog);                                                                  // Destruir el diálogo de advertencia
        return;                                                                                      // Salir de la función
    }

    const char *codigo = gtk_entry_get_text(GTK_ENTRY(entry_codigo)); // Obtener el texto del código

    if (codigo == NULL || strlen(codigo) == 0)
    { // Validar que no esté vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "El campo está vacío."); // Crear un diálogo de advertencia
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                    // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                 // Mostrar el diálogo de advertencia
        gtk_widget_destroy(dialog);                                                         // Destruir el diálogo de advertencia
        return;                                                                             // Salir de la función
    }

    Producto producto; // Crear una estructura Producto
    if (!buscar_producto("productos.txt", codigo, &producto))
    { // Buscar el producto por código
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "Producto no encontrado."); // Crear un diálogo de advertencia
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                       // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                    // Mostrar el diálogo de advertencia
        gtk_widget_destroy(dialog);                                                            // Destruir el diálogo de advertencia
        return;                                                                                // Salir de la función
    }

    GtkWidget *dialog = gtk_message_dialog_new(
        NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_YES_NO,
        "Producto: %s\n"
        "Precio: %.2f\nCantidad: %d\n\n"
        "¿Está seguro de que desea eliminar el producto?",
        producto.nombre, producto.precio, producto.cantidad); // Crear un diálogo de confirmación
    gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);       // Centrar el cuadro de diálogo
    gint respuesta = gtk_dialog_run(GTK_DIALOG(dialog));                   // Ejecutar el diálogo de confirmación
    gtk_widget_destroy(dialog);                                            // Destruir el diálogo de confirmación

    if (respuesta == GTK_RESPONSE_YES)
    { // Si la respuesta es "Sí"
        if (eliminar_producto("productos.txt", codigo))
        { // Eliminar el producto
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                       GTK_BUTTONS_OK, "Producto eliminado correctamente."); // Crear un diálogo de éxito
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                                 // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                                                              // Mostrar el diálogo de éxito
            gtk_widget_destroy(dialog);                                                                      // Destruir el diálogo de éxito
            gtk_widget_destroy(gtk_widget_get_toplevel(widget));                                             // Cerrar la ventana del formulario
            return;                                                                                          // Salir de la función
        }
        else
        {
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                       GTK_BUTTONS_OK, "Error al eliminar el producto."); // Crear un diálogo de error
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                              // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                                                           // Mostrar el diálogo de error
            gtk_widget_destroy(dialog);                                                                   // Destruir el diálogo de error
            return;                                                                                       // Salir de la función
        }
    }
}
