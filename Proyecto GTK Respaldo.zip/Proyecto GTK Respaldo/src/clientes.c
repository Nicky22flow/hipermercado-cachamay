//clientes.c
#include "clientes.h" // Incluir el archivo de cabecera para la estructura Empleado y funciones relacionadas
#include <stdio.h>     // Incluir la biblioteca estándar de entrada/salida
#include <stdlib.h>    // Incluir la biblioteca estándar de utilidades
#include <string.h>    // Incluir la biblioteca estándar de manejo de cadenas
#include <ctype.h>     // Incluir la biblioteca estándar de funciones de caracteres

void crear_ventana_clientes(GtkWidget *widget, gpointer data) {
    GtkWidget *window; // Puntero a la ventana principal
    GtkWidget *box; // Puntero al contenedor vertical para los botones
    GtkWidget *button; // Puntero a los botones de la interfaz

    // Crear una nueva ventana de la aplicación
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Gestión de Clientes"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300); // Establecer el tamaño predeterminado de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana en la pantalla

    GdkRGBA color;
    gdk_rgba_parse(&color, "#387647"); //Color de la ventana   
    G_GNUC_BEGIN_IGNORE_DEPRECATIONS
    gtk_widget_override_background_color(GTK_WIDGET(window), GTK_STATE_FLAG_NORMAL, &color);
    G_GNUC_BEGIN_IGNORE_DEPRECATIONS

    // Crear un GtkBox vertical para centrar los botones
    box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_set_halign(box, GTK_ALIGN_CENTER); // Centrar horizontalmente el GtkBox
    gtk_widget_set_valign(box, GTK_ALIGN_CENTER); // Centrar verticalmente el GtkBox
    gtk_container_add(GTK_CONTAINER(window), box); // Agregar el GtkBox a la ventana

    // Botón para registrar un cliente
    button = gtk_button_new_with_label("Registrar Cliente");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_formulario_registro), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Botón para modificar un cliente
    button = gtk_button_new_with_label("Modificar Cliente");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_formulario_modificar_cliente), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Botón para eliminar un cliente
    button = gtk_button_new_with_label("Eliminar Cliente");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_formulario_eliminar_cliente), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Botón para buscar un cliente
    button = gtk_button_new_with_label("Mostrar Clientes");
    g_signal_connect(button, "clicked", G_CALLBACK(mostrar_clientes), NULL); // Conectar la señal "clicked" al callback
    gtk_box_pack_start(GTK_BOX(box), button, TRUE, TRUE, 0); // Agregar el botón al GtkBox

    // Mostrar todos los widgets en la ventana
    gtk_widget_show_all(window);
}

void mostrar_formulario_registro(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog;  //puntero a GtkWidget para el diálogo
    GtkWidget *content_area;    //puntero a GtkWidget para el área de contenido del diálogo
    GtkWidget *grid;    //puntero a GtkWidget para la cuadrícula dentro del área de contenido
    GtkWidget *label;   //puntero a GtkWidget para una etiqueta dentro de la cuadrícula
    GtkWidget **entrys = g_malloc(sizeof(GtkWidget *) * 5); // Array para almacenar los campos de entrada

    // Crear un nuevo cuadro de diálogo con botones "Cancelar" y "Registrar"
    dialog = gtk_dialog_new_with_buttons("Registrar Cliente",
                                        GTK_WINDOW(gtk_widget_get_toplevel(widget)),
                                        GTK_DIALOG_MODAL,
                                        "_Cancelar", GTK_RESPONSE_CANCEL,
                                        "Registrar", GTK_RESPONSE_ACCEPT,
                                        NULL);
    gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo

    // Obtener el área de contenido del cuadro de diálogo
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    grid = gtk_grid_new(); // Crear una nueva cuadrícula para organizar los widgets
    gtk_container_add(GTK_CONTAINER(content_area), grid); // Agregar la cuadrícula al área de contenido

    // Crear y agregar los campos de entrada al grid
    const char *labels[] = {"Cédula", "Nombre", "Apellido", "Dirección", "Teléfono"};
    for (int i = 0; i < 5; i++) {
        label = gtk_label_new(labels[i]); // Crear una nueva etiqueta para cada campo
        entrys[i] = gtk_entry_new(); // Crear un nuevo campo de entrada
        gtk_grid_attach(GTK_GRID(grid), label, 0, i, 1, 1); // Agregar la etiqueta a la cuadrícula
        gtk_grid_attach(GTK_GRID(grid), entrys[i], 1, i, 1, 1); // Agregar el campo de entrada a la cuadrícula
    }

    // Conectar la señal "response" del diálogo a la función guardar_cliente_callback
    g_signal_connect(dialog, "response", G_CALLBACK(guardar_cliente_callback), entrys);

    gtk_widget_show_all(dialog); // Mostrar todos los widgets en el cuadro de diálogo
}

void mostrar_formulario_modificar_cliente(GtkWidget *widget, gpointer data) {
    GtkWidget *window, *grid, *boton_buscar, *boton_guardar; // Declaración de widgets para la ventana, cuadrícula y botones
    GtkWidget **entrys = g_malloc0(sizeof(GtkWidget *) * 5); // Array para almacenar los campos de entrada
    GtkWidget *label; // Declaración de widget para las etiquetas
    const char *labels[] = {"Cédula", "Nombre", "Apellido", "Dirección", "Teléfono"}; // Etiquetas para los campos de entrada

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL); // Crear una nueva ventana
    gtk_window_set_title(GTK_WINDOW(window), "Modificar Cliente"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300); // Establecer el tamaño predeterminado de la ventana
    gtk_container_set_border_width(GTK_CONTAINER(window), 10); // Establecer el ancho del borde de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana

    grid = gtk_grid_new(); // Crear una nueva cuadrícula para organizar los widgets
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5); // Establecer el espaciado entre filas
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5); // Establecer el espaciado entre columnas
    gtk_container_add(GTK_CONTAINER(window), grid); // Agregar la cuadrícula al contenedor de la ventana

    for (int i = 0; i < 5; i++) { // Iterar sobre las etiquetas y campos de entrada
        label = gtk_label_new(labels[i]); // Crear una nueva etiqueta
        entrys[i] = gtk_entry_new(); // Crear un nuevo campo de entrada
        gtk_grid_attach(GTK_GRID(grid), label, 0, i, 1, 1); // Agregar la etiqueta a la cuadrícula
        gtk_grid_attach(GTK_GRID(grid), entrys[i], 1, i, 1, 1); // Agregar el campo de entrada a la cuadrícula
    }

    // Botón para buscar
    boton_buscar = gtk_button_new_with_label("Buscar"); // Crear un nuevo botón con la etiqueta "Buscar"
    gtk_grid_attach(GTK_GRID(grid), boton_buscar, 2, 0, 1, 1); // Agregar el botón a la cuadrícula
    g_signal_connect(boton_buscar, "clicked", G_CALLBACK(buscar_cliente_callback), entrys); // Conectar la señal "clicked" al callback

    // Botón para guardar cambios
    boton_guardar = gtk_button_new_with_label("Guardar Cambios"); // Crear un nuevo botón con la etiqueta "Guardar Cambios"
    gtk_grid_attach(GTK_GRID(grid), boton_guardar, 1, 5, 1, 1); // Agregar el botón a la cuadrícula
    g_signal_connect(boton_guardar, "clicked", G_CALLBACK(guardar_cliente_modificado), entrys); // Conectar la señal "clicked" al callback

    gtk_widget_show_all(window); // Mostrar todos los widgets en la ventana
}

void mostrar_formulario_eliminar_cliente(GtkWidget *widget, gpointer data) {
    GtkWidget *window; // Puntero a la ventana principal
    GtkWidget *grid; // Puntero a la cuadrícula para organizar los widgets
    GtkWidget *label_cedula; // Puntero a la etiqueta para el campo de cédula
    GtkWidget *entry_cedula; // Puntero al campo de entrada para la cédula
    GtkWidget *button_eliminar; // Puntero al botón de eliminar

    // Crear una nueva ventana
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Eliminar Cliente"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 300, 50); // Establecer el tamaño predeterminado de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana

    // Crear una nueva cuadrícula y agregarla a la ventana
    grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    // Crear una etiqueta para el campo de cédula y agregarla a la cuadrícula
    label_cedula = gtk_label_new("Cédula:");
    gtk_grid_attach(GTK_GRID(grid), label_cedula, 0, 0, 1, 1);

    // Crear un campo de entrada para la cédula y agregarlo a la cuadrícula
    entry_cedula = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grid), entry_cedula, 1, 0, 2, 1);

    // Crear un botón de eliminar y agregarlo a la cuadrícula
    button_eliminar = gtk_button_new_with_label("Eliminar");
    gtk_grid_attach(GTK_GRID(grid), button_eliminar, 3, 0, 1, 1);

    // Conectar el botón "Eliminar" al callback
    g_signal_connect(button_eliminar, "clicked", G_CALLBACK(eliminar_cliente_callback), entry_cedula);

    // Mostrar todos los widgets en la ventana
    gtk_widget_show_all(window);
}

void mostrar_clientes(GtkWidget *widget, gpointer data) {
    // Crear una nueva ventana
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Lista de Clientes"); // Establecer el título de la ventana
    gtk_window_set_default_size(GTK_WINDOW(window), 500, 200); // Establecer el tamaño predeterminado de la ventana
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER); // Centrar la ventana

    // Crear un contenedor vertical
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_add(GTK_CONTAINER(window), vbox); // Agregar el contenedor vertical a la ventana

    // Crear un contenedor con desplazamiento para los clientes
    GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0); // Agregar el contenedor con desplazamiento al contenedor vertical

    // Crear una tabla para mostrar los datos de los clientes
    GtkWidget *grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5); // Establecer el espaciado entre filas
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10); // Establecer el espaciado entre columnas
    gtk_container_add(GTK_CONTAINER(scrolled_window), grid); // Agregar la tabla al contenedor con desplazamiento

    // Encabezados de la tabla
    const char *headers[] = {"Cédula", "Nombre", "Apellido", "Dirección", "Teléfono"};
    int num_headers = sizeof(headers) / sizeof(headers[0]); // Calcular el número de encabezados

    for (int col = 0; col < num_headers; col++) {
        GtkWidget *label = gtk_label_new(headers[col]); // Crear un label para cada encabezado
        gtk_grid_attach(GTK_GRID(grid), label, col * 2, 0, 1, 1); // Agregar el label a la tabla
        if (col < num_headers - 1) {
            gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_VERTICAL), col * 2 + 1, 0, 1, 1); // Agregar un separador vertical
        }
    }

    // Leer clientes desde el archivo
    FILE *file_clientes = fopen("clientes.txt", "r");
    if (!file_clientes) { // Verificar si se pudo abrir el archivo de clientes
        GtkWidget *error_dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                        GTK_BUTTONS_OK,
                                                        "Error: No se pudo abrir el archivo de clientes.");
        gtk_dialog_run(GTK_DIALOG(error_dialog)); // Mostrar un cuadro de diálogo de error
        gtk_widget_destroy(error_dialog); // Destruir el cuadro de diálogo de error
        return;
    }

    // Leer y mostrar cada cliente
    char linea[512];
    int row = 1;
    while (fgets(linea, sizeof(linea), file_clientes)) { // Leer cada línea del archivo
        Cliente cliente;
        sscanf(linea, "%[^,],%[^,],%[^,],%[^,],%[^,]",
            cliente.cedula, cliente.nombre, cliente.apellido,
            cliente.direccion, cliente.telefono); // Parsear los datos del cliente

        // Crear etiquetas para cada campo y agregar al grid
        const char *datos[] = {cliente.cedula, cliente.nombre, cliente.apellido, cliente.direccion, cliente.telefono};
        for (int col = 0; col < num_headers; col++) {
            GtkWidget *label = gtk_label_new(datos[col]); // Crear un label para cada dato
            gtk_grid_attach(GTK_GRID(grid), label, col * 2, row, 1, 1); // Agregar el label a la tabla
            if (col < num_headers - 1) {
                gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_VERTICAL), col * 2 + 1, row, 1, 1); // Agregar un separador vertical
            }
        }

        // Separador horizontal
        gtk_grid_attach(GTK_GRID(grid), gtk_separator_new(GTK_ORIENTATION_HORIZONTAL), 0, row + 1, num_headers * 2 - 1, 1); // Agregar un separador horizontal

        row += 2; // Incrementar la fila
    }
    fclose(file_clientes); // Cerrar el archivo de clientes

    // Mostrar la ventana con todos los datos
    gtk_widget_show_all(window);
}

// Callback para guardar un cliente
void guardar_cliente_callback(GtkDialog *dialog, gint response_id, gpointer user_data)
{
    GtkWidget **entrys = (GtkWidget **)user_data; // Obtener los widgets de entrada

    if (response_id == GTK_RESPONSE_ACCEPT)
    {                   // Si la respuesta es aceptar
        Cliente cliente; // Crear una estructura Cliente

        // Obtener los valores de los campos de entrada
        const char *cedula = gtk_entry_get_text(GTK_ENTRY(entrys[0]));    // Obtener texto de la cédula
        const char *nombre = gtk_entry_get_text(GTK_ENTRY(entrys[1]));    // Obtener texto del nombre
        const char *apellido = gtk_entry_get_text(GTK_ENTRY(entrys[2]));  // Obtener texto del apellido
        const char *direccion = gtk_entry_get_text(GTK_ENTRY(entrys[3])); // Obtener texto de la dirección
        const char *telefono = gtk_entry_get_text(GTK_ENTRY(entrys[4]));  // Obtener texto del teléfono

        // Copiar los valores a la estructura Cliente
        strncpy(cliente.cedula, cedula, sizeof(cliente.cedula) - 1);       // Copiar la cédula
        cliente.cedula[sizeof(cliente.cedula) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
        strncpy(cliente.nombre, nombre, sizeof(cliente.nombre) - 1);       // Copiar el nombre
        cliente.nombre[sizeof(cliente.nombre) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
        strncpy(cliente.apellido, apellido, sizeof(cliente.apellido) - 1); // Copiar el apellido
        cliente.apellido[sizeof(cliente.apellido) - 1] = '\0';             // Asegurarse de que la cadena termine en nulo
        strncpy(cliente.direccion, direccion, sizeof(cliente.direccion) - 1); // Copiar la dirección
        cliente.direccion[sizeof(cliente.direccion) - 1] = '\0';           // Asegurarse de que la cadena termine en nulo
        strncpy(cliente.telefono, telefono, sizeof(cliente.telefono) - 1); // Copiar el teléfono
        cliente.telefono[sizeof(cliente.telefono) - 1] = '\0';             // Asegurarse de que la cadena termine en nulo

        // Validar campos y registrar el cliente
        if (validar_campos_cliente(cliente) && registrar_cliente("clientes.txt", cliente))
        {                                                                          // Si los campos son válidos y el registro es exitoso
            GtkWidget *success_dialog = gtk_message_dialog_new(GTK_WINDOW(dialog), // Crear un diálogo de éxito
                                                               GTK_DIALOG_MODAL,
                                                               GTK_MESSAGE_INFO,
                                                               GTK_BUTTONS_OK,
                                                               "Cliente registrado correctamente.");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(success_dialog));                      // Mostrar el diálogo de éxito
            gtk_widget_destroy(success_dialog);                              // Destruir el diálogo de éxito
            gtk_widget_destroy(GTK_WIDGET(dialog));                          // Cerrar el diálogo solo si el registro es exitoso
            g_free(entrys);                                                  // Liberar la memoria de las entradas solo si el registro es exitoso
        }
    }
    else
    {                                           // Si la respuesta no es aceptar
        gtk_widget_destroy(GTK_WIDGET(dialog)); // Cerrar el diálogo si se cancela
        g_free(entrys);                         // Liberar la memoria de las entradas si se cancela
    }
}

int registrar_cliente(const char *archivo, Cliente cliente)
{
    // Validar los campos del cliente
    if (!validar_campos_cliente(cliente))
    {
        return 0; // Fallo en la validación
    }

    // Verificar si la cédula ya está registrada
    if (cedula_duplicada_cliente(archivo, cliente.cedula))
    {
        // Mostrar un mensaje de advertencia si la cédula ya está registrada
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "La cédula ya está registrada.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
        return 0; // Fallo
    }

    // Abrir el archivo en modo de adición
    FILE *file = fopen(archivo, "a");
    if (!file)
        return 0; // Fallo al abrir el archivo

    // Escribir los datos del cliente en el archivo
    fprintf(file, "%s,%s,%s,%s,%s\n",
            cliente.cedula, cliente.nombre, cliente.apellido,
            cliente.direccion, cliente.telefono);
    fclose(file); // Cerrar el archivo
    return 1;     // Éxito
}

int validar_campos_cliente(Cliente cliente)
{
    // Validar cédula
    if (strlen(cliente.cedula) == 0)
    { // Verificar si el campo 'Cédula' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Cédula' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }
    for (size_t i = 0; i < strlen(cliente.cedula); i++)
    { // Recorrer cada carácter de la cédula
        if (!g_ascii_isdigit(cliente.cedula[i]))
        { // Verificar si no es un dígito
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK, "Error: La cédula solo puede contener dígitos.");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
            gtk_widget_destroy(dialog);                                      // Destruir el diálogo
            return 0;                                                        // Retornar 0 indicando error
        }
    }

    // Validar nombre
    if (strlen(cliente.nombre) == 0)
    { // Verificar si el campo 'Nombre' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Nombre' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }
    for (size_t i = 0; i < strlen(cliente.nombre); i++)
    { // Recorrer cada carácter del nombre
        if (!g_ascii_isalpha(cliente.nombre[i]))
        { // Verificar si no es una letra
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK, "Error: El nombre solo puede contener letras.");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
            gtk_widget_destroy(dialog);                                      // Destruir el diálogo
            return 0;                                                        // Retornar 0 indicando error
        }
    }

    // Validar apellido
    if (strlen(cliente.apellido) == 0)
    { // Verificar si el campo 'Apellido' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Apellido' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }
    for (size_t i = 0; i < strlen(cliente.apellido); i++)
    { // Recorrer cada carácter del apellido
        if (!g_ascii_isalpha(cliente.apellido[i]))
        { // Verificar si no es una letra
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK, "Error: El apellido solo puede contener letras.");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
            gtk_widget_destroy(dialog);                                      // Destruir el diálogo
            return 0;                                                        // Retornar 0 indicando error
        }
    }

    // Validar dirección
    if (strlen(cliente.direccion) == 0)
    { // Verificar si el campo 'Dirección' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Dirección' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }

    // Validar teléfono
    if (strlen(cliente.telefono) == 0)
    { // Verificar si el campo 'Teléfono' está vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Teléfono' está vacío.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
        return 0;                                                        // Retornar 0 indicando error
    }
    for (size_t i = 0; i < strlen(cliente.telefono); i++)
    { // Recorrer cada carácter del teléfono
        if (!g_ascii_isdigit(cliente.telefono[i]))
        { // Verificar si no es un dígito
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                       GTK_BUTTONS_OK, "Error: El teléfono solo puede contener dígitos.");
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar mensaje de error
            gtk_widget_destroy(dialog);                                      // Destruir el diálogo
            return 0;                                                        // Retornar 0 indicando error
        }
    }

    return 1; // Validación exitosa
}

int cedula_duplicada_cliente(const char *archivo, const char *cedula)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
        return 0; // Si el archivo no existe, no hay duplicados

    char linea[256]; // Buffer para leer cada línea del archivo
    while (fgets(linea, sizeof(linea), file))
    {                                             // Leer línea por línea
        char cedula_existente[20];                // Buffer para almacenar la cédula existente
        sscanf(linea, "%[^,]", cedula_existente); // Extraer la cédula de la línea
        if (strcmp(cedula, cedula_existente) == 0)
        {                 // Comparar la cédula con la cédula existente
            fclose(file); // Cerrar el archivo
            return 1;     // Cédula encontrada, hay duplicado
        }
    }
    fclose(file); // Cerrar el archivo
    return 0;     // No se encontró duplicado
}

int modificar_cliente(const char *archivo, const char *cedula, Cliente nuevo_cliente)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
        return 0; // Si no se puede abrir el archivo, retornar 0

    FILE *temp = fopen("temp.txt", "w"); // Crear un archivo temporal en modo escritura
    if (!temp)
    {                 // Si no se puede crear el archivo temporal
        fclose(file); // Cerrar el archivo original
        return 0;     // Retornar 0
    }

    char linea[512];    // Buffer para leer cada línea del archivo
    int encontrado = 0; // Variable para indicar si se encontró el cliente

    while (fgets(linea, sizeof(linea), file))
    {                      // Leer línea por línea del archivo
        Cliente cliente;   // Crear una estructura Cliente
        sscanf(linea, "%[^,],%[^,],%[^,],%[^,],%[^,]",
               cliente.cedula, cliente.nombre, cliente.apellido,
               cliente.direccion, cliente.telefono); // Extraer los datos del cliente de la línea

        if (strcmp(cliente.cedula, cedula) == 0)
        {                   // Si la cédula coincide con la buscada
            encontrado = 1; // Marcar como encontrado
            // Escribir los datos del nuevo cliente en el archivo temporal
            fprintf(temp, "%s,%s,%s,%s,%s\n",
                    nuevo_cliente.cedula, nuevo_cliente.nombre, nuevo_cliente.apellido,
                    nuevo_cliente.direccion, nuevo_cliente.telefono);
        }
        else
        {                       // Si la cédula no coincide
            fputs(linea, temp); // Escribir la línea original en el archivo temporal
        }
    }

    fclose(file);                // Cerrar el archivo original
    fclose(temp);                // Cerrar el archivo temporal
    remove(archivo);             // Eliminar el archivo original
    rename("temp.txt", archivo); // Renombrar el archivo temporal al nombre original

    return encontrado; // Retornar si se encontró el cliente
}

void buscar_cliente_callback(GtkWidget *widget, gpointer data)
{
    GtkWidget **entrys = (GtkWidget **)data; // Obtener los widgets de entrada

    // Validar que el campo de cédula sea un GtkEntry
    if (!GTK_IS_ENTRY(entrys[0]))
    {
        g_warning("El campo de cédula no es un GtkEntry válido."); // Mostrar advertencia si no es un GtkEntry válido
        return;                                                    // Salir de la función
    }

    const char *cedula = gtk_entry_get_text(GTK_ENTRY(entrys[0])); // Obtener el texto de la cédula
    Cliente cliente;                                               // Crear una estructura Cliente

    // Buscar el cliente por cédula
    if (buscar_cliente("clientes.txt", cedula, &cliente))
    {
        // Si se encuentra el cliente, llenar los campos con sus datos
        gtk_entry_set_text(GTK_ENTRY(entrys[1]), cliente.nombre);           // Establecer el nombre
        gtk_entry_set_text(GTK_ENTRY(entrys[2]), cliente.apellido);         // Establecer el apellido
        gtk_entry_set_text(GTK_ENTRY(entrys[3]), cliente.direccion);        // Establecer la dirección
        gtk_entry_set_text(GTK_ENTRY(entrys[4]), cliente.telefono);         // Establecer el teléfono
    }
    else
    {
        // Si no se encuentra el cliente, mostrar un mensaje de error
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Cliente no encontrado.");
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER); // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                              // Mostrar el diálogo de error
        gtk_widget_destroy(dialog);                                      // Destruir el diálogo
    }
}

// Función para buscar un cliente por cédula
int buscar_cliente(const char *archivo, const char *cedula, Cliente *cliente)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
        return 0; // Si no se puede abrir el archivo, retornar 0

    char buffer[512]; // Buffer para leer cada línea del archivo
    while (fgets(buffer, sizeof(buffer), file))
    { // Leer línea por línea del archivo
        // Extraer los datos del cliente de la línea
        sscanf(buffer, "%[^,],%[^,],%[^,],%[^,],%[^,]",
               cliente->cedula, cliente->nombre, cliente->apellido,
               cliente->direccion, cliente->telefono);

        if (strcmp(cliente->cedula, cedula) == 0)
        {                 // Comparar la cédula con la cédula buscada
            fclose(file); // Cerrar el archivo
            return 1;     // Retornar 1 si se encuentra el cliente
        }
    }
    fclose(file); // Cerrar el archivo
    return 0;     // Retornar 0 si no se encuentra el cliente
}

void guardar_cliente_modificado(GtkWidget *widget, gpointer data)
{
    GtkWidget **entrys = (GtkWidget **)data; // Obtener los widgets de entrada

    // Validar que todos los widgets sean GtkEntry
    for (int i = 0; i < 5; i++)
    {
        if (!GTK_IS_ENTRY(entrys[i]))
        {                                                                       // Si no es un GtkEntry válido
            g_warning("El campo en el índice %d no es un GtkEntry válido.", i); // Mostrar advertencia
            return;                                                             // Salir de la función
        }
    }

    Cliente cliente;                                             // Crear una estructura Cliente
    const char *cedula = gtk_entry_get_text(GTK_ENTRY(entrys[0])); // Obtener texto de la cédula

    if (!cedula || strlen(cedula) == 0)
    { // Si la cédula está vacía
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error: El campo 'Cédula' está vacío."); // Crear un diálogo de error
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                                    // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                                 // Mostrar el diálogo de error
        gtk_widget_destroy(dialog);                                                                         // Destruir el diálogo de error
        return;                                                                                             // Salir de la función
    }

    // Obtener los valores de los campos de entrada
    const char *nombre = gtk_entry_get_text(GTK_ENTRY(entrys[1]));    // Obtener texto del nombre
    const char *apellido = gtk_entry_get_text(GTK_ENTRY(entrys[2]));  // Obtener texto del apellido
    const char *direccion = gtk_entry_get_text(GTK_ENTRY(entrys[3])); // Obtener texto de la dirección
    const char *telefono = gtk_entry_get_text(GTK_ENTRY(entrys[4]));  // Obtener texto del teléfono

    // Copiar los valores a la estructura Cliente
    strncpy(cliente.cedula, cedula, sizeof(cliente.cedula) - 1);       // Copiar la cédula
    cliente.cedula[sizeof(cliente.cedula) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
    strncpy(cliente.nombre, nombre, sizeof(cliente.nombre) - 1);       // Copiar el nombre
    cliente.nombre[sizeof(cliente.nombre) - 1] = '\0';                 // Asegurarse de que la cadena termine en nulo
    strncpy(cliente.apellido, apellido, sizeof(cliente.apellido) - 1); // Copiar el apellido
    cliente.apellido[sizeof(cliente.apellido) - 1] = '\0';             // Asegurarse de que la cadena termine en nulo
    strncpy(cliente.direccion, direccion, sizeof(cliente.direccion) - 1); // Copiar la dirección
    cliente.direccion[sizeof(cliente.direccion) - 1] = '\0';           // Asegurarse de que la cadena termine en nulo
    strncpy(cliente.telefono, telefono, sizeof(cliente.telefono) - 1); // Copiar el teléfono
    cliente.telefono[sizeof(cliente.telefono) - 1] = '\0';             // Asegurarse de que la cadena termine en nulo

    if (modificar_cliente("clientes.txt", cedula, cliente))
    { // Si la modificación es exitosa
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "Cliente modificado correctamente."); // Crear un diálogo de éxito
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                                  // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                               // Mostrar el diálogo de éxito
        gtk_widget_destroy(dialog);                                                                       // Destruir el diálogo de éxito
    }
    else
    { // Si hay un error en la modificación
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_ERROR,
                                                   GTK_BUTTONS_OK, "Error al modificar el cliente."); // Crear un diálogo de error
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                              // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                           // Mostrar el diálogo de error
        gtk_widget_destroy(dialog);                                                                   // Destruir el diálogo de error
    }
}

int eliminar_cliente(const char *archivo, const char *cedula)
{
    FILE *file = fopen(archivo, "r"); // Abrir el archivo en modo lectura
    if (!file)
    {
        perror("Error al abrir el archivo"); // Mostrar error si no se puede abrir el archivo
        return 0;                            // Retornar 0 indicando fallo
    }

    FILE *temp = fopen("temp.txt", "w"); // Crear un archivo temporal en modo escritura
    if (!temp)
    {
        perror("Error al crear el archivo temporal"); // Mostrar error si no se puede crear el archivo temporal
        fclose(file);                                 // Cerrar el archivo original
        return 0;                                     // Retornar 0 indicando fallo
    }

    char buffer[512];   // Buffer para leer cada línea del archivo
    int encontrado = 0; // Variable para indicar si se encontró el cliente

    while (fgets(buffer, sizeof(buffer), file))
    {                                             // Leer línea por línea del archivo
        char cedula_actual[20];                   // Buffer para almacenar la cédula actual
        sscanf(buffer, "%19[^,]", cedula_actual); // Extraer la cédula (hasta la primera coma)

        if (strcmp(cedula_actual, cedula) == 0)
        {
            encontrado = 1; // Marcar como encontrado si la cédula coincide
        }
        else
        {
            fputs(buffer, temp); // Copiar las líneas no coincidentes al archivo temporal
        }
    }

    fclose(file); // Cerrar el archivo original
    fclose(temp); // Cerrar el archivo temporal

    // Reemplazar el archivo original solo si se encontró el cliente
    if (encontrado)
    {
        remove(archivo);             // Eliminar el archivo original
        rename("temp.txt", archivo); // Renombrar el archivo temporal al nombre original
    }
    else
    {
        remove("temp.txt"); // Eliminar el archivo temporal si no se encontró nada
    }

    return encontrado; // Retornar si se encontró el cliente
}

void eliminar_cliente_callback(GtkWidget *widget, gpointer data)
{
    GtkWidget *entry_cedula = GTK_WIDGET(data); // Obtener el GtkEntry pasado como "data"

    if (!GTK_IS_ENTRY(entry_cedula))
    { // Validar que sea un GtkEntry
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "El campo Cédula no es válido."); // Crear un diálogo de advertencia
        gtk_dialog_run(GTK_DIALOG(dialog));                                                          // Mostrar el diálogo de advertencia
        gtk_widget_destroy(dialog);                                                                  // Destruir el diálogo de advertencia
        return;                                                                                      // Salir de la función
    }

    const char *cedula = gtk_entry_get_text(GTK_ENTRY(entry_cedula)); // Obtener el texto de la cédula

    if (cedula == NULL || strlen(cedula) == 0)
    { // Validar que no esté vacío
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "El campo está vacío."); // Crear un diálogo de advertencia
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                    // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                 // Mostrar el diálogo de advertencia
        gtk_widget_destroy(dialog);                                                         // Destruir el diálogo de advertencia
        return;                                                                             // Salir de la función
    }

    Cliente cliente; // Crear una estructura Cliente
    if (!buscar_cliente("clientes.txt", cedula, &cliente))
    { // Buscar el cliente por cédula
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                   GTK_BUTTONS_OK, "Cliente no encontrado."); // Crear un diálogo de advertencia
        gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                       // Centrar el cuadro de diálogo
        gtk_dialog_run(GTK_DIALOG(dialog));                                                    // Mostrar el diálogo de advertencia
        gtk_widget_destroy(dialog);                                                            // Destruir el diálogo de advertencia
        return;                                                                                // Salir de la función
    }

    GtkWidget *dialog = gtk_message_dialog_new(
        NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_WARNING, GTK_BUTTONS_YES_NO,
        "Cliente: %s %s\n"
        "Dirección: %s\nTeléfono: %s\n\n"
        "¿Está seguro de que desea eliminar al cliente?",
        cliente.nombre, cliente.apellido,
        cliente.direccion, cliente.telefono); // Crear un diálogo de confirmación
    gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);       // Centrar el cuadro de diálogo
    gint respuesta = gtk_dialog_run(GTK_DIALOG(dialog));                   // Ejecutar el diálogo de confirmación
    gtk_widget_destroy(dialog);                                            // Destruir el diálogo de confirmación

    if (respuesta == GTK_RESPONSE_YES)
    { // Si la respuesta es "Sí"
        if (eliminar_cliente("clientes.txt", cedula))
        { // Eliminar el cliente
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                       GTK_BUTTONS_OK, "Cliente eliminado correctamente."); // Crear un diálogo de éxito
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                                 // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                                                              // Mostrar el diálogo de éxito
            gtk_widget_destroy(dialog);                                                                      // Destruir el diálogo de éxito
            gtk_widget_destroy(gtk_widget_get_toplevel(widget));                                             // Cerrar la ventana del formulario
            return;                                                                                          // Salir de la función
        }
        else
        {
            GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO,
                                                       GTK_BUTTONS_OK, "Error al eliminar el cliente."); // Crear un diálogo de error
            gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);                              // Centrar el cuadro de diálogo
            gtk_dialog_run(GTK_DIALOG(dialog));                                                           // Mostrar el diálogo de error
            gtk_widget_destroy(dialog);                                                                   // Destruir el diálogo de error
            return;                                                                                       // Salir de la función
        }
    }
}

int leerClientesDesdeArchivo(const char *archivo, Cliente *clientes, int *num_clientes) {
    FILE *file = fopen(archivo, "r");
    if (!file) {
        perror("Error al abrir el archivo de clientes");
        return 0;
    }

    char buffer[256];
    *num_clientes = 0;
    while (fgets(buffer, sizeof(buffer), file)) {
        sscanf(buffer, "%[^,],%[^,],%[^,],%[^,],%[^,\n]",
               clientes[*num_clientes].cedula,
               clientes[*num_clientes].nombre,
               clientes[*num_clientes].apellido,
               clientes[*num_clientes].direccion,
               clientes[*num_clientes].telefono);
        (*num_clientes)++;
    }

    fclose(file);
    return 1;
}

Cliente obtener_cliente_seleccionado(GtkComboBoxText *combo_cliente, Cliente *clientes, int num_clientes) {
    int cliente_index = gtk_combo_box_get_active(GTK_COMBO_BOX(combo_cliente));
    if (cliente_index < 0 || cliente_index >= num_clientes) {
        Cliente cliente_vacio = {"", "", "", "", ""};
        return cliente_vacio;
    }
    return clientes[cliente_index];
}

int buscar_cliente_por_cedula(const char *archivo, const char *cedula, Cliente *cliente) {
    FILE *file = fopen(archivo, "r");
    if (!file) {
        perror("Error al abrir el archivo de clientes");
        return 0;
    }

    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file)) {
        sscanf(buffer, "%[^,],%[^,],%[^,],%[^,],%[^,]",
               cliente->cedula, cliente->nombre, cliente->apellido,
               cliente->direccion, cliente->telefono);

        if (strcmp(cliente->cedula, cedula) == 0) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}
