// control_cajas.c
#include "control_cajas.h"
#include "clientes.h"
#include "facturas.h"
#include "productos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#define ARCHIVO_CAJAS "cajas.txt"

// Función para guardar las cajas en un archivo
void guardar_cajas(Caja *cajas, int cantidad) {
    FILE *archivo = fopen(ARCHIVO_CAJAS, "w");
    if (!archivo) return;
    for (int i = 0; i < cantidad; i++) {
        fprintf(archivo, "%d,%d,%s,%.2f,%.2f,%.2f,%.2f\n",
                cajas[i].numero_caja, cajas[i].numero_empleado,
                cajas[i].nombre_responsable, cajas[i].total_bs,
                cajas[i].total_usd, cajas[i].total_cop, cajas[i].total_eur);
    }
    fclose(archivo);
}

// Función para cargar las cajas desde un archivo
int cargar_cajas_desde_archivo(Caja *cajas) {
    FILE *archivo = fopen(ARCHIVO_CAJAS, "r");
    if (!archivo) return 0;
    int i = 0;
    while (fscanf(archivo, "%d,%d,%99[^,],%f,%f,%f,%f\n", &cajas[i].numero_caja,
                &cajas[i].numero_empleado, cajas[i].nombre_responsable,
                &cajas[i].total_bs, &cajas[i].total_usd,
                &cajas[i].total_cop, &cajas[i].total_eur) == 7) {
        i++;
    }
    fclose(archivo);
    return i;
}

// Función para cargar las cajas en la interfaz gráfica
void cargar_cajas(GtkWidget *treeview) {
    Caja cajas[100];
    int cantidad = cargar_cajas_desde_archivo(cajas);
    
    GtkListStore *store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_INT, G_TYPE_STRING);
    GtkTreeIter iter;
    
    for (int i = 0; i < cantidad; i++) {
        gtk_list_store_append(store, &iter);
        gtk_list_store_set(store, &iter, 0, cajas[i].numero_caja, 1, cajas[i].numero_empleado, 2, cajas[i].nombre_responsable, -1);
    }
    
    gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
    g_object_unref(store);
}

// Función para agregar una caja desde la GUI
void on_agregar_caja(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry_numero, *entry_empleado, *entry_nombre;
    dialog = gtk_dialog_new_with_buttons("Agregar Caja", GTK_WINDOW(data), GTK_DIALOG_MODAL, "Aceptar", GTK_RESPONSE_OK, "Cancelar", GTK_RESPONSE_CANCEL, NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry_numero = gtk_entry_new();
    entry_empleado = gtk_entry_new();
    entry_nombre = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_numero), "Número de caja");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_empleado), "Número de empleado");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_nombre), "Nombre del responsable");
    gtk_box_pack_start(GTK_BOX(content_area), entry_numero, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_empleado, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_nombre, FALSE, FALSE, 5);
    gtk_widget_show_all(dialog);
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        Caja nueva_caja;
        nueva_caja.numero_caja = atoi(gtk_entry_get_text(GTK_ENTRY(entry_numero)));
        nueva_caja.numero_empleado = atoi(gtk_entry_get_text(GTK_ENTRY(entry_empleado)));
        strcpy(nueva_caja.nombre_responsable, gtk_entry_get_text(GTK_ENTRY(entry_nombre)));
        nueva_caja.total_bs = nueva_caja.total_usd = nueva_caja.total_cop = nueva_caja.total_eur = 0.0;
        Caja cajas[100];
        int cantidad = cargar_cajas_desde_archivo(cajas);
        cajas[cantidad] = nueva_caja;
        cantidad++;
        guardar_cajas(cajas, cantidad);
    }
    gtk_widget_destroy(dialog);
}

// Función para modificar una caja desde la GUI
void on_modificar_caja(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry_numero, *entry_empleado, *entry_nombre;
    dialog = gtk_dialog_new_with_buttons("Modificar Caja", GTK_WINDOW(data), GTK_DIALOG_MODAL, "Aceptar", GTK_RESPONSE_OK, "Cancelar", GTK_RESPONSE_CANCEL, NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry_numero = gtk_entry_new();
    entry_empleado = gtk_entry_new();
    entry_nombre = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_numero), "Número de caja");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_empleado), "Número de empleado");
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_nombre), "Nombre del responsable");
    gtk_box_pack_start(GTK_BOX(content_area), entry_numero, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_empleado, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(content_area), entry_nombre, FALSE, FALSE, 5);
    gtk_widget_show_all(dialog);
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        int numero_caja = atoi(gtk_entry_get_text(GTK_ENTRY(entry_numero)));
        Caja cajas[100];
        int cantidad = cargar_cajas_desde_archivo(cajas);
        for (int i = 0; i < cantidad; i++) {
            if (cajas[i].numero_caja == numero_caja) {
                cajas[i].numero_empleado = atoi(gtk_entry_get_text(GTK_ENTRY(entry_empleado)));
                strcpy(cajas[i].nombre_responsable, gtk_entry_get_text(GTK_ENTRY(entry_nombre)));
                guardar_cajas(cajas, cantidad);
                break;
            }
        }
    }
    gtk_widget_destroy(dialog);
}

// Función para eliminar una caja desde la GUI
void on_eliminar_caja(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry_numero;
    dialog = gtk_dialog_new_with_buttons("Eliminar Caja", GTK_WINDOW(data), GTK_DIALOG_MODAL, "Aceptar", GTK_RESPONSE_OK, "Cancelar", GTK_RESPONSE_CANCEL, NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry_numero = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry_numero), "Número de caja");
    gtk_box_pack_start(GTK_BOX(content_area), entry_numero, FALSE, FALSE, 5);
    gtk_widget_show_all(dialog);
    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        int numero_caja = atoi(gtk_entry_get_text(GTK_ENTRY(entry_numero)));
        Caja cajas[100];
        int cantidad = cargar_cajas_desde_archivo(cajas);
        int i, j;
        for (i = 0; i < cantidad; i++) {
            if (cajas[i].numero_caja == numero_caja) {
                for (j = i; j < cantidad - 1; j++) {
                    cajas[j] = cajas[j + 1];
                }
                cantidad--;
                guardar_cajas(cajas, cantidad);
                break;
            }
        }
    }
    gtk_widget_destroy(dialog);
}

void on_registrar_venta(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *combo_box;
    Caja cajas[100];
    int cantidad = cargar_cajas_desde_archivo(cajas);

    dialog = gtk_dialog_new_with_buttons("Seleccionar Caja", GTK_WINDOW(data), GTK_DIALOG_MODAL, "Aceptar", GTK_RESPONSE_OK, "Cancelar", GTK_RESPONSE_CANCEL, NULL);
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    combo_box = gtk_combo_box_text_new();

    for (int i = 0; i < cantidad; i++) {
        char caja_info[100];
        sprintf(caja_info, "Caja %d - %s", cajas[i].numero_caja, cajas[i].nombre_responsable);
        gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_box), caja_info);
    }

    gtk_box_pack_start(GTK_BOX(content_area), combo_box, FALSE, FALSE, 5);
    gtk_widget_show_all(dialog);

    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_OK) {
        int selected_index = gtk_combo_box_get_active(GTK_COMBO_BOX(combo_box));
        if (selected_index >= 0) {
            Caja caja_seleccionada = cajas[selected_index];
            gtk_widget_destroy(dialog);
            abrir_interfaz_registro_venta(GTK_WINDOW(gtk_widget_get_toplevel(widget)), &caja_seleccionada);
        }
    } else {
        gtk_widget_destroy(dialog);
    }
}

void abrir_interfaz_registro_venta(GtkWindow *parent_window, Caja *caja) {
    GtkWidget *window, *vbox, *hbox, *label, *combo_cliente, *button_nuevo_cliente, *button_agregar, *button_finalizar;
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_transient_for(GTK_WINDOW(window), parent_window);
    gtk_window_set_title(GTK_WINDOW(window), "Registrar Venta");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    // Selección de cliente
    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    label = gtk_label_new("Cliente:");
    combo_cliente = gtk_combo_box_text_new();
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(hbox), combo_cliente, TRUE, TRUE, 5);
    button_nuevo_cliente = gtk_button_new_with_label("Nuevo Cliente");
    gtk_box_pack_start(GTK_BOX(hbox), button_nuevo_cliente, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

    // Cargar clientes desde el archivo
    Cliente clientes[100];
    int num_clientes = cargar_clientes_desde_archivo(clientes);
    for (int i = 0; i < num_clientes; i++) {
        char cliente_info[100];
        snprintf(cliente_info, sizeof(cliente_info), "%s - %s", clientes[i].nombre, clientes[i].cedula);
        gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_cliente), cliente_info);
    }

    // Conectar el botón de nuevo cliente
    g_signal_connect(button_nuevo_cliente, "clicked", G_CALLBACK(mostrar_formulario_registro), window);

    // Selección de producto
    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    label = gtk_label_new("Producto:");
    GtkWidget *combo_producto = gtk_combo_box_text_new();
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(hbox), combo_producto, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

    // Cargar productos desde el archivo
    Producto *productos = g_malloc(sizeof(Producto) * 100);
    int num_productos = cargar_productos_desde_archivo(productos);
    for (int i = 0; i < num_productos; i++) {
        gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_producto), productos[i].nombre);
    }

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    label = gtk_label_new("Cantidad:");
    GtkWidget *entry_cantidad = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(hbox), entry_cantidad, TRUE, TRUE, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

    button_agregar = gtk_button_new_with_label("Agregar Producto");
    button_finalizar = gtk_button_new_with_label("Finalizar Venta");
    gtk_box_pack_start(GTK_BOX(vbox), button_agregar, FALSE, FALSE, 5);
    gtk_box_pack_start(GTK_BOX(vbox), button_finalizar, FALSE, FALSE, 5);

    // Crear la estructura de la factura
    Factura *factura = g_malloc(sizeof(Factura));
    factura->num_productos = 0;

    // Crear la estructura de datos de venta
    DatosVenta *datos_venta = g_malloc(sizeof(DatosVenta));
    datos_venta->combo_producto = combo_producto;
    datos_venta->entry_cantidad = entry_cantidad;
    datos_venta->productos = productos;
    datos_venta->num_productos = num_productos;
    datos_venta->factura = factura;
    datos_venta->num_items = 0;
    datos_venta->clientes = clientes;
    datos_venta->num_clientes = num_clientes;
    datos_venta->combo_cliente = combo_cliente;
    datos_venta->caja = caja; // Asignar la caja seleccionada

    // Conectar los botones a sus callbacks
    g_signal_connect(button_agregar, "clicked", G_CALLBACK(on_agregar_producto), datos_venta);
    g_signal_connect(button_finalizar, "clicked", G_CALLBACK(on_finalizar_venta), datos_venta);

    gtk_widget_show_all(window);
}

void on_agregar_producto(GtkWidget *widget, gpointer data) {
    DatosVenta *datos_venta = (DatosVenta *)data;
    const char *nombre_producto = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(datos_venta->combo_producto));
    
    if (!nombre_producto) {
        printf("Error: No se seleccionó un producto.\n");
        return;
    }

    Producto producto;
    int encontrado = 0;

    // Buscar el producto en la lista actualizada
    for (int i = 0; i < datos_venta->num_productos; i++) {
        if (g_strcmp0(datos_venta->productos[i].nombre, nombre_producto) == 0) {
            producto = datos_venta->productos[i];
            encontrado = 1;
            break;
        }
    }

    if (!encontrado) {
        printf("Error: Producto no encontrado.\n");
        return;
    }

    // Obtener la cantidad del producto
    const char *cantidad_str = gtk_entry_get_text(GTK_ENTRY(datos_venta->entry_cantidad));
    int cantidad = atoi(cantidad_str);
    if (cantidad <= 0) {
        printf("Error: Cantidad inválida.\n");
        return;
    }

    // Agregar el producto a la lista de ventas
    if (datos_venta->num_items < MAX_ITEMS_VENTA) {
        producto.cantidad = cantidad;
        datos_venta->items[datos_venta->num_items] = producto;
        datos_venta->num_items++;
        printf("Producto agregado: %s\n", producto.nombre);

        // Agregar el producto a la factura
        agregarProducto(datos_venta->factura, producto);

        // Mostrar un mensaje de confirmación
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Producto agregado.");
        gtk_dialog_run(GTK_DIALOG(dialog));
        gtk_widget_destroy(dialog);
    } else {
        printf("Error: No se pueden agregar más productos a la venta.\n");
    }
}

void agregarProducto(Factura *factura, Producto producto) {
    if (factura->num_productos < MAX_ITEMS_VENTA) {
        factura->productos[factura->num_productos] = producto;
        factura->num_productos++;
    } else {
        printf("Error: No se pueden agregar más productos a la factura.\n");
    }
}

void calcularTotales(Factura *factura, float tasa_cambio, float monto_base, float iva) {
    float subtotal = 0.0;
    for (int i = 0; i < factura->num_productos; i++) {
        subtotal += factura->productos[i].precio * factura->productos[i].cantidad;
    }
    float impuesto = subtotal * (iva / 100.0);
    factura->monto_total = subtotal + impuesto;
    factura->impuesto = iva;
}

// filepath: /c:/Users/PC-Core i5/Documents/Proyecto GTK/src/control_cajas.c
void on_finalizar_venta(GtkWidget *widget, gpointer data) {
    DatosVenta *datos_venta = (DatosVenta *)data;
    Factura *factura = datos_venta->factura;

    // Obtener el cliente seleccionado
    int cliente_index = gtk_combo_box_get_active(GTK_COMBO_BOX(datos_venta->combo_cliente));
    if (cliente_index < 0 || cliente_index >= datos_venta->num_clientes) {
        printf("Error: No se seleccionó un cliente válido.\n");
        return;
    }
    Cliente cliente = datos_venta->clientes[cliente_index];

    // Asignar el cliente a la factura
    factura->cliente = cliente;

    // Asignar el número de caja a la factura
    factura->numero_caja = datos_venta->caja->numero_caja;

    // Calcular totales y guardar la factura en el archivo
    factura->impuesto = 16.0; // Ejemplo de impuesto del 16%
    calcularTotales(factura, 4.0, 2500.0, 3.8); // Tasa de cambio de ejemplo
    guardarFacturaEnArchivo(*factura, "facturas.txt");

    // Mostrar la factura en una ventana
    mostrarFormatoFactura(*factura);

    // Mostrar un mensaje de confirmación
    GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK, "Venta finalizada.");
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);

    // Cerrar la ventana de registro de venta
    gtk_widget_destroy(GTK_WIDGET(datos_venta->combo_producto));

    // Liberar la memoria
    g_free(datos_venta->productos);
    g_free(datos_venta->factura);
    g_free(datos_venta);
}

// Implementación de la función cargar_productos_desde_archivo
int cargar_productos_desde_archivo(Producto *productos) {
    FILE *archivo = fopen("productos.txt", "r");
    if (!archivo) {
        printf("Error: No se pudo abrir el archivo de productos.\n");
        return 0;
    }

    int i = 0;
    while (fscanf(archivo, "%7[^,],%49[^,],%f,%d\n", 
                  productos[i].codigo, productos[i].nombre, 
                  &productos[i].precio, &productos[i].cantidad) == 4) {
        i++;
        if (i >= 100) break; // Evitar desbordamiento
    }
    fclose(archivo);
    return i;
}

// Función para cargar los clientes desde un archivo
int cargar_clientes_desde_archivo(Cliente *clientes) {
    FILE *archivo = fopen("clientes.txt", "r");
    if (!archivo) {
        printf("Error: No se pudo abrir el archivo de clientes.\n");
        return 0;
    }

    int i = 0;
    while (fscanf(archivo, "%19[^,],%49[^,],%49[^,],%99[^,],%11[^\n]\n",
                  clientes[i].cedula, clientes[i].nombre, clientes[i].apellido,
                  clientes[i].direccion, clientes[i].telefono) == 5) {
        i++;
        if (i >= 100) break; // Evitar desbordamiento
    }
    fclose(archivo);
    return i;
}