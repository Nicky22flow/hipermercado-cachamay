// filepath: /c:/Users/PC-Core i5/Documents/Proyecto GTK/src/control_cajas.h
#ifndef CONTROL_CAJAS_H
#define CONTROL_CAJAS_H
#define MAX_ITEMS_VENTA 100
#include <gtk/gtk.h>
#include "productos.h"
#include "facturas.h"

// Estructura de la caja
typedef struct {
    int numero_caja;
    int numero_empleado;
    char nombre_responsable[100];
    float total_bs, total_usd, total_cop, total_eur;
} Caja;

typedef struct {
    GtkWidget *combo_producto;
    GtkWidget *entry_cantidad;
    Producto *productos;
    int num_productos;
    Factura *factura;
    Producto items[MAX_ITEMS_VENTA];
    int num_items;
    Cliente *clientes;
    int num_clientes;
    GtkWidget *combo_cliente;
    Caja *caja; // Agregar el miembro caja
} DatosVenta;

// Prototipos de funciones
void guardar_cajas(Caja *cajas, int cantidad);
int cargar_cajas_desde_archivo(Caja *cajas);
void cargar_cajas(GtkWidget *treeview);
void on_agregar_caja(GtkWidget *widget, gpointer data);
void on_modificar_caja(GtkWidget *widget, gpointer data);
void on_eliminar_caja(GtkWidget *widget, gpointer data);
void on_registrar_venta(GtkWidget *widget, gpointer data);
void abrir_interfaz_registro_venta(GtkWindow *parent_window, Caja *caja);
int cargar_productos_desde_archivo(Producto *productos);
int cargar_clientes_desde_archivo(Cliente *clientes);
void on_agregar_producto(GtkWidget *widget, gpointer data);
void on_finalizar_venta(GtkWidget *widget, gpointer data);
void mostrar_ventana_control_cajas();
void agregarProducto(Factura *factura, Producto producto);
void calcularTotales(Factura *factura, float tasa_cambio, float monto_base, float iva);

#endif // CONTROL_CAJAS_H